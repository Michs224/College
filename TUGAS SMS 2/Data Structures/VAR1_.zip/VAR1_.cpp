#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>

char *brack(char str[]){
	int i=0;
	while(!isdigit(str[i])){
		if(str[i]==NULL)return &str[i];
		printf("%c",str[i]);
		i++;
	}
//	printf("%dd\n",i);
	char strdigit[31]={NULL};
	int k=0;
	while(str[i]!='['){
		strdigit[k]=str[i];
		k++;
		i++;
	}
//	printf("%df\n",i);
	int kurung=1;
	int ulang=atoi(strdigit);
//	printf("%d\n",ulang);
	int start=i+1;
//	int y=start;
	char tampung[31]={NULL};
//	int c=0;
	for(i=start;kurung!=0;i++){
		if(str[i]=='['){
			kurung++;
		}
		else if(str[i]==']'){
			kurung--;
		}
//		else{
//			tampung[c]=str[i];
//		}
//		c++;
//		y++;
//		printf("%d\n",i);
	}
	int end=i-2;
//	printf("%d\n",end);
	for(i=0;i<ulang;i++){
		for(int j=start;j<=end;j++){
			if(isdigit(str[j])){
				char *temp=strstr(str,&str[j]);
				char *strrr=brack(temp);
				int selisih=strrr-&str[j];
				j=j+selisih-1;
				continue;
			}
			
			printf("%c",str[j]);
		}
	}
	int endd=end+2;
	return &str[endd];
	
	
}


int main(){
	char str[100];
	
	int T;
	scanf("%d",&T);
	for(int i=0;i<T;i++){
		scanf(" %[^\n]",str);
		printf("Case #%d: ",i+1);
		char *strr;
		
		strr=brack(str);
		while(*strr!=NULL){
			strr=brack(strr);
		}
		
		printf("\n");
	}
	
	
	return 0;
}
