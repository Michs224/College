#include <stdio.h>
#include <stdlib.h>

struct Node {
    int data;
    struct Node *prev;
    struct Node *next;
};

void insert(struct Node **head, int data) {
    struct Node *temp = (struct Node *) malloc(sizeof(struct Node));

    temp->data = data;

    if (*head == NULL) {
        temp->next = temp;
        temp->prev = temp;
        *head = temp;
    } else {
        struct Node *last = *head;
        temp->next = (*head);
        while(last->next != *head)  
            last = last->next;

        temp->prev = last;
        last->next = temp;
    }
    
    // head points to newNode
    (*head) = temp;
}

void display(struct Node *head)
{
     // If list is empty
    if (head == NULL)
        printf("\nList is empty\n");

    // Else print the list
    else {
        struct Node *temp;
        temp = head;
  
        do {
            printf("\nData = %d", temp->data);
            temp = temp->next;
        } while (temp->next != head->next);
    }
}

int main() {
    struct Node *last = NULL;
    insert(&last, 100);
    insert(&last, 80);
    insert(&last, 30);
    display(last);
    return 0;
}