//Benedictus Cristiano Budi
//2602137496
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

struct node{
    struct node *prev;
	char type[10];
	int weight;
	struct node *next;
};

void insert(struct node **head, char types[10], int val){
	struct node *temp = (struct node*) malloc(sizeof(struct node));
	if(*head == NULL){
		strcpy(temp->type, types);
    	temp->weight = val;
    	temp->next = temp->prev = temp;
    	*head = temp;
	}
	else{
		struct node *last = (*head)->prev;
		strcpy(temp->type, types);
	    temp->weight = val;
	    temp->next = *head;
	    temp->prev = last;
	    *head = temp;
	}
}

int deleteFinal(struct node **head){
    int flags;
    if(*head == NULL){
        printf("Linked list is empty\n");
        flags = 1;
    }
    else{
        struct node *current = *head;
        if(current->prev != NULL){
            current->prev->next = NULL;
        }
        else{
            *head = NULL;
        }
        free(current);
        flags = 0;
    }
    return flags;
}

void display(struct node *test){
	if(test == NULL){
		printf("");
	}
	else{
	printf("[%s grain\t| %3dkg<s>] -> top\n", test->type, test->weight);
	test = test->next;
	while(test != NULL){
		printf("[%s grain\t| %3dkg<s>]\n", test->type, test->weight);
	    test = test->next;
	}
	}
}

int main(){
    struct node *head = NULL;

	char types[4][10] = {"long", "medium", "short"};
	
	int flag;
	int weigh;
	int reset=1;
	int choice;
	int check;
	char grain[10];
	
	int nodeTotal = 0;
	
	do{
		do{
			system("CLS");
			printf("BLUE RICE STOCK\n");
			printf("^^^^^^^^^^^^^^^\n");
			printf(" Rice stock <STACK>\n\n");
			display(head);
			printf("\n");
			printf("Option :\n");
			printf("1. Stock Rice Sack\n");
		 	printf("2. Sell Rice Sack\n");
			printf("3. Exit\n\n");
			printf(">>Input choice : ");
			check = scanf("%d", &choice);
			fflush(stdin);
		}while(check != 1 || choice <=0 || choice > 3);
		
		
		switch(choice){
		
		case 1:
			system("CLS");
			if(nodeTotal >= 10){
				printf("--- The Rice Storage is Full\n\n");
			}
			else{
			do{
			printf("Input Rice Type [long/medium/short] grain : ");
			scanf("%s", grain);
			for(int i = 0; i<3; i++){
				if(strcmp(grain, types[i]) == 0){
					flag = 0;
					break;
				}
				else{
					flag = 1;
				}
			}
			}while(flag == 1);
			
			do{
			printf("Input weight of The Rice Sack [10..100 kg<s>] : ");
			check = scanf("%d", &weigh);
			fflush(stdin);
			}while(check !=1 || weigh<10 || weigh>100);
			insert(&head, grain, weigh);
			printf("--Add Rice Sack Success--\n\n");
			nodeTotal++;
			}
			do{
				printf("Return to main menu?\n");
				printf("1.Yes\n2.No\n");
				printf(">>Input choice : ");
				check = scanf("%d", &reset);
				fflush(stdin);
			}while(check !=1 || reset <= 0 || reset > 2);
		break;
		
		case 2:
			system("CLS");
            flag = deleteFinal(&head);
			if(flag != 1){
				printf("-- Sell Rice Sack Success --\n\n");
				nodeTotal--;
			}
			do{
				printf("Return to main menu?\n");
				printf("1.Yes\n2.No\n");
				printf(">>Input choice : ");
				check = scanf("%d", &reset);
				fflush(stdin);
			}while(check !=1 || reset < 1 || reset > 2);
			break;
		
		
		default:
			reset = 2;
			system("CLS");
			printf("Exiting...");
			break;
		}
		
		
		
	}while(reset == 1);
	
	
	return 0;
}
