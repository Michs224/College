//Kenrick 2602148682

#include <stdio.h>
#include <string.h>
#include <stdlib.h>

int flag=0, stock=0;

struct data
{
	char type[100];
	int weight;
	struct data *next;
};

void insert (struct data **rice, char tipe1[], int weight)
{
	struct data *temp = (struct data*) malloc (sizeof(struct data));
	
	strcpy(temp->type, tipe1);
	strcat(temp->type, " grain");
	temp -> weight = weight;
	temp -> next = *rice;
	
	*rice = temp;
}

void display (struct data *rice)
{
	int n=0;
	
	while (rice != NULL)
	{
		if (n == 0)
		{
			printf("[ %-20s | %d kg(s)] -> [top]\n", rice->type, rice->weight);
			rice = rice->next;
			
			n++;
		}
		
		else
		{
			printf("[ %-20s | %d kg(s)]\n", rice->type, rice->weight);
			rice = rice->next;
		}
	}
	
	n = 0;
}

void sell (struct data **rice)
{
	struct data *temp = *rice;
	if (temp != NULL)
	{
		temp = temp -> next;
		printf("--- Sell Rice Sack Success ---\n\n");
	}
	
	else
	{
		printf("--- The Rice Storage is Empty ---\n\n");
	}
	
	*rice = temp;
}

int main()
{
	int menu=1;
	
	struct data *rice = NULL;
	
	do
	{
		printf("BLUE rice SHOP CASHIER\n");
		printf("^^^^^^^^^^^^^^^^^^^^^^\n\n");
		printf("Rice Stock <STACK>\n\n");
		display(rice);
		printf("\n\n");
		
		printf("Option :\n");
		printf("1. Stock Rice Sack\n");
		printf("2. Sell Rice Sack\n");
		printf("3. Exit\n");
		
		do
		{
			if (menu < 1 || menu > 3)
			{
				printf("\nInvalid menu input\n");
			}
			printf(">> Input choice : ");
			scanf("%d", &menu);
		}
		while (menu < 1 || menu > 3);
		
		if (menu != 3) printf("\n");
		
		if (menu == 1) //Stock Rice
		{
			if (stock < 10)
			{
				char type[3][7] = {"long", "medium", "short"};
				char tipe1[7];
				int berat=0;
				
				type:
					
				printf("Input Rice Type [long/medium/short] grain: ");
				scanf("%s", &tipe1);
				
				for (int p=0; p<sizeof(type); p++)
				{
					if (strcmp(type[p], tipe1) == 0)
					{
						flag = 1;
						break;
					}
				}
				
				if (flag == 1)
				{
					flag = 0;
					weight:
						
					printf("Input Weight of The Rice Sack [10..100 kg(s)]: ");
					scanf("%d", &berat);
					
					if (berat < 10 || berat > 100)
					{
						goto weight;
					}
					
					else
					{
						insert(&rice, tipe1, berat);
						stock ++;
						printf("\n\n--- Add Rice Sack Success ---\n\n");
					}
				}
				
				else
				{
					goto type;
				}
			}
			
			else
			{
				printf("--- Stock is Already Full ---\n\n");
			}
		}
		
		if (menu == 2) //Sell Rice Sack
		{
			sell(&rice);
			stock--;
		}
	}
	while (menu != 3);
	return 0;
}
