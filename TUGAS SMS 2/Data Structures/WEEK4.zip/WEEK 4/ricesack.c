#include <stdio.h>

struct data {
	char type[10];
	int weight;
	struct data *next
};

int count =0;

void insert(struct data **head, int weight1, char type1[]) {//syntax untuk membikin node data yang dari int main dimasukin ke voide insert
	if (count >=10){
		
	}
	else{
	    struct data *new_rice = (struct data *) malloc(sizeof(struct data)); // syntax link list
	    strcpy(new_rice->type, type1);//buat new rice nya jadi type1
	    new_rice->weight = weight1;//buat new rice nya weight jadi weight1
	    new_rice->next = *head;//array nya gabung terus (mulai daria awal)->biar next nya lanjut ke node berikutnya
	    *head = new_rice;//struct new rice agar struct head menjadi new rice
	    count++;
	}
}

void display(struct data **head) {// kalau link list harus ada struct data** head
	struct data *new_rice = *head;//bikin struct namanya new rice isinya head yang diatas (strcpy->head)
    while (new_rice != NULL) {//kalau belum insert new rice link list nya ksong jadi masi 0 (untuk validasi kalau new rice nya udsah keisi)
        printf("[ %s grain | %d kg(s) ]\n"  , new_rice->type, new_rice->weight);//ngeprint rice nya
        new_rice = new_rice->next;//di next agar masuk node ke 2 ke 3 sampai habis
    }
}

void sell(struct data **head){// link list
	struct data *temp=*head;
	if (*head==NULL){//validasi kalau dia belum masukin apa apa rice storagenya empty
		printf ("The Rice storage is empty\n");
	}
	else {
	temp=temp->next;//hapus yang paling atas link list yang paling pertama temp nya dijadikan next(temp kan head  temp jadi next buat masuk jadi  node 2 head dipindah ke temp node pertama ne jadi ilang)
	*head = temp;//next nya dijadiin head head nya langsung kedua
	count--;// biar dikurangin 1 kalau jual jadi mines
	}
}

int main (){
	int x;
	char type1[10];
	int weight1;
	
	struct data *head = NULL;// link list nya dibikin paling belakang 
	
	do{
		printf ("Rice System\n");
		printf ("--------------\n");
		printf ("Rice Stock  <stack>\n");
		display (&head);//untuk masukin functionnya display
		printf ("\n");
		
		printf ("Option :\n");
		printf ("1. Stock Rice Rack\n");
		printf ("2. Sell Rice Rack\n");
		printf ("3. Exit\n");
		scanf ("%d", &x);
		
		if (x==1){//
			if (count>=10){//kalau sudah 10 gbsa nmbah lgi
				printf ("--------------\n");
				printf ("RICE STORAGE IS FULL\n");
				printf ("--------------\n\n");
			}
			else {
				printf ("Insert the type of rice (long/medium/short) : ");
				scanf ("%s", &type1);//string 
				do{
					printf ("Insert the weight of the rice sack [10...100] : ");
					scanf ("%d", &weight1);
					if (weight1 <10 || weight1 >100){//range nya 10-100
						printf ("Please re-input the valid weight\n");
					}
				} while (weight1 <10 || weight1 >100);//kalo ga 10-100 ngulang lagi
				
				insert (&head,weight1,type1);//buat masuk void insert untuk lempar weight1,type1 ke function
				printf ("----- Add Stock Success -----\n\n");
			}
		}
		if (x==2){//untuk ngejual nasi paling atas
			sell(&head);
		}
	}while (x!=3);//kalo x belum tiga  keluar dari program
}
