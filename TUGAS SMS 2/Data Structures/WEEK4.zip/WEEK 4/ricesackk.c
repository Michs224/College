#include <stdio.h>
#include <stdlib.h>

struct rice{
	char tipe[7];
	int weight;
	struct rice *next;
};

void insert(struct rice **head, char tipe[7], int value){
	struct rice *temp = (struct rice*) malloc(sizeof(struct rice));
	strcpy(temp->tipe, tipe);
	temp->weight = value;
	
	temp->next = *head;
	
	*head = temp;
	
}

void display(struct rice *test){
	if(test == NULL){
		printf("");
	}else{
		printf("[%s grain\t| %3dkg<s>] -> top\n", test->tipe, test->weight);
		test = test->next;
	while(test != NULL){
		printf("[%s grain\t| %3dkg<s>]\n", test->tipe, test->weight);
		test = test->next;
		}
	}
}

int deletes(struct rice **head){
	int flag;
    struct rice *temp = (struct rice*) malloc(sizeof(struct rice));
    if(*head == NULL){
        printf("Linked list is empty\n");
        flag = 1;
    }
    else{
        *head = (*head) ->next;
        free(*head);
    }
    return flag;
}

int main(){
	struct rice *head = NULL;
	int pil, cek, i, flag, weights, res;
	char grain[7];
	
	char tipe[3][7] = {"long", "medium", "short"};
	int total = 0;
	
	do{
		do{
		printf("BLUE RICE STOCK\n");
		printf("^^^^^^^^^^^^^^^\n\n");
		printf("  Rice Stock <STACK>\n\n");
		display(head);
		printf("Option : \n");
		printf("1. Stock Rice Sack\n");
		printf("2. Sell Rice Sack\n");
		printf("3. Exit\n");
		printf(">> Input choice : ");
		cek = scanf("%d", &pil);
		}while(pil < 1 || pil > 3 || cek != 1);
		switch(pil){
			case 1:
				if(total >= 10){
					printf("---The rice storage is full---\n");
				}else{
					do{
						printf("Input type of rice : ");
						scanf("%s", grain);
						for(i=0; i<3; i++){
							if(strcmp(grain, tipe[i]) == 0){
								flag = 0; //berhasil
								break;
							}else{
								flag = 1; //gak berhasil
						}
					}
				}while(flag == 1);
				do{
					printf("Input weight of rice stack [10-100]kg : ");
					cek = scanf("%d", &weights);
					fflush(stdin);
				}while(weights < 10 || weights > 100 || cek != 1);
				insert(&head, grain, weights);
				printf("---Add Rice Sack Success---\n\n");
				total++;
				}
				do{
					printf("Return to main menu?\n");
					printf("1.Yes\n");
					printf("2.No\n");
					printf(">>Input choice : ");
					cek = scanf("%d", &res);
					fflush(stdin);
				}while(cek !=1 || res <= 0 || res > 2);
				break;
			
			case 2:
				flag = deletes(&head);
				if(flag != 1){
					printf("---Sell Rice Sack Success---\n");
					total--;
				}
				do{
					printf("Return to main menu?\n");
					printf("1.Yes\n");
					printf("2.No\n");
					printf(">>Input choice : ");
					cek = scanf("%d", &res);
					fflush(stdin);
				}while(cek !=1 || res <= 0 || res > 2);
				break;	
			
			default:
				res = 2;
				printf("Exit..."); //exit
		}
	}while(res == 1);
		
	return 0;
}