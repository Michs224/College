#include <stdio.h>
#include <ctype.h>
#include <string.h>
#include <stdlib.h>

struct data {
	char name[30];
	struct data *next;
} *hashTable[26], *curr;

void insertEnd(int hashKey, char name[]) {
	struct data *temp = (struct data *) malloc(sizeof(struct data));
	strcpy(temp->name, name);
	temp->next = NULL;
	
	if(hashTable[hashKey] == NULL) {
		hashTable[hashKey] = temp;
	} else {
		curr = hashTable[hashKey];
		
		while(curr->next != NULL) {
			curr = curr->next;
		}
		
		curr->next = temp;
	}
}

void display() {
	printf("\n");
	int i = 0;
	for(i=0;i<26;i++) {
		printf("HashKey [%d] : ", i);
		curr = hashTable[i];
		while(curr != NULL) {
			printf("%s ", curr->name);
			curr = curr->next;
		}
		printf("\n");
	}
}

int hashFunction(char name[]) {
	int hashKey = -1;
	char fChar = name[0];
	hashKey = tolower(fChar) - 97;
	return hashKey;
}

int main() {
	char name[30];
	int flag = 0;
	do {
		printf("Input name : ");
		scanf("%[^\n]", name);getchar();
		if(strcmp(name, "exit")==0) break;
		insertEnd(hashFunction(name), name);
	} while(1);
	display();
	
	return 0;
}
