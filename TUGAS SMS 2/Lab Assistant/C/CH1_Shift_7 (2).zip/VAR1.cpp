#include <stdio.h>

int main(){
	int P,E,T;
	char x;
	scanf("%d %d",&P,&E);
	scanf("%d",&T);
	for(int i=0;i<T;i++){
		scanf(" %c",&x);
		if(x=='e')P-=2;
		else if(x=='E')P-=5;
		else if(x=='o')E-=2;
		else if(x=='O')E-=5;
		
		
	}
	if(P<=0){
		printf("Enemy Win\n");
	}
	else if(E<=0){
		printf("Player Win\n");
	}
	else{
		printf("Draw\n");
	}
	
	
	return 0;
}
