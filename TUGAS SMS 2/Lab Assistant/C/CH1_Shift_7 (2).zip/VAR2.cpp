#include <stdio.h>

int strlength(char str[]){
	int i;
	for(i=0;str[i]!=NULL;i++){
	}
	printf("%d\n",i);
	return i;
	
}

int main(){
	char str1[31],str2[31]={NULL};
	
	int T,count=0;
	
	scanf("%d",&T);getchar();
	for(int i=0;i<T;i++){
		scanf("%[^\n]",str1);getchar();
		int n=strlength(str1);
		count=0;
//		printf("%d\n",n);
		for(int j=0;j<n;j++){
			if(str1[j]>='A' && str1[j]<='Z')str1[j]=str1[j]+32;
		}
		for(int j=0;j<n;j++){
			str2[j]=str1[n-1-j];
		}
	
//		printf("%s\n",str1);
//		printf("%s\n",str2);
		for(int i=0;i<n;i++){
			if(str2[i]==str1[i])count++;
//			printf("%d\n",count);
		}
		if(count==n){
			printf("Palindrome\n");
		}
		else printf("Not Palindrome\n");
		
	}
	
	
	
	
	
	return 0;
}
