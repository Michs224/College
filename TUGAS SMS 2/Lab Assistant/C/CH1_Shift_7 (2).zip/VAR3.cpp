#include <stdio.h>

int main() {
    int T;
    scanf("%d", &T);
	int x=T;
    char curr_char = 'a';
    int k=1;
    for (int i = 1; i <= T; i++) {
        for (int j = 1; j <=T; j++) {
//        	printf("%d\n",x);
        	if(j<x)printf(" ");
        	else {
        		for(int z=1;z<=k;z++){
        			printf("%c",curr_char);
					curr_char = (curr_char == 'z') ? 'a' : curr_char + 1;
				}
				k+=2;
				break;
			}
			
            
        }x--;
        curr_char='a';
        printf("\n");
    }

    return 0;
}
