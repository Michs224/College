#include <stdio.h>

int strlength(char str[]){
	int i;
	for(i=0;str[i]!=NULL;i++){
	}
	printf("%d\n",i);
	return i;
	
}

int main(){
	
	int T;
	char str[100];
	int c1=0,c2=0,c3=0,c4=0,C;
	scanf("%d",&T);getchar();
	
	for(int i=0;i<T;i++){
		scanf("%[^\n]",str);getchar();
//		printf("%s\n",str);
		int n=strlength(str);
//		printf("%d\n",n);
		C=0;
		for(int j=0;j<n;j++){
			if(str[j]>='A' && str[j]<='Z')c1=1;
			if(str[j]>='a' && str[j]<='z')c2=1;
			if(str[j]>='0' && str[j]<='9')c3=1;
			if(str[j]>=33 && str[j]<=47 || str[j]>=58 && str[j]<=64 || str[j]>=91 && str[j]<=96 || str[j]>=123 && str[j]<=126) c4=1;
		
		}
		C=c1+c3+c3+c4;
		printf("%d\n",C);
		if(C==1)printf("None\n");
		else if(C==2) printf("Weak\n");
		else if(C==3) printf("Medium\n");
		else printf("Strong\n");
		
	}
	
}
