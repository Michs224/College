#include <stdio.h>


int strlength(char str[]){
	int i;
	for(i=0;str[i]!=NULL;i++){
	}
	printf("%d\n",i);
	return i;
	
}

int main(){
	char T[10001];
	char tampung[10001];
	scanf("%[^\n]",T);
	int n=strlength(T);
	printf("%d\n",n);
	for(int i=0;i<n;i++){
		
		for(int j=0;j<n;j++){
			tampung[j]=T[j];
		}
		for(int j=0;j<n;j++){
			if(tampung[j]>='A' && tampung[j]<='Z'){
				tampung[j]=tampung[j]+32;
			}
		}
//		123aAabBCDdEZzRre
//      123aAabBCDdEZzRre
//		printf("%s\n",tampung);
//	for(int k=0;k<n-1;k++){
//		for(int j=0;j<n-k-1;j++){
//			if(tampung[j]>tampung[j+1] || (tampung[j]==tampung[j+1] && T[j] < T[j+1])){
//				char tukar=T[j];
//				T[j]=T[j+1];
//				T[j+1]=tukar;
//			}
//		}		
//	}
//selection
//	for(int k=0;k<n-1;k++){
//		int idx=k;
//		for(int j=k+1;j<n;j++){
//			if(tampung[idx]>tampung[j] || (tampung[idx]==tampung[j] && T[idx] < T[j])){
//				idx=j;
//			}
//		}
//		char tukar=T[idx];
//			T[idx]=T[k];
//			T[k]=tukar;		
//	}
//selection
	for(int k=0;k<n-1;k++){
		for(int j=k+1;j<n;j++){
			if(tampung[k]>tampung[j] || (tampung[k]==tampung[j] && T[k] < T[j])){
				char tukar=T[k];
				T[k]=T[j];
				T[j]=tukar;
			}
		}	
	}

	}
	printf("%s\n",T);
}
