#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <conio.h>
#include <time.h>

//Sorry, I think the time is not enough


int strlength(char str[]){
	int i;
	for(i=0;str[i]!=NULL;i++){
	}
//	printf("%d\n",i);
	return i;
	
}

int random(){
	int i, random_number;
    srand(time(NULL));
    
    for (i = 0; i < 10; i++) {
        random_number = rand() % 9 + 1;
        printf("%d\n", random_number);
    }
    return random_number;
}


char map[11][24]={"  0 1 2 3 4 5 6 7 8 9\n",
			  "0 . . . . . . . . . .\n",
			  "1 . . . . . . . . . .\n",
			  "2 . . . . . . . . . .\n",
			  "3 . . . . . . . . . .\n",
			  "4 . . . . . . . . . .\n",
			  "5 . . . . . . . . . .\n",
			  "6 . . . . . . . . . .\n",
			  "7 . . . . . . . . . .\n",
			  "8 . . . . . . . . . .\n",
			  "9 . . . . . . . . . .\n",
	
			};

void dismap(){
	for(int i=0;i<10;i++){
		for(int j=0;j<21;j++){
			printf("%c",map[i][j]);
		}puts("");
	}
}

void clear(){
    #if defined(__linux__) || defined(__unix__) || defined(__APPLE__)
        system("clear");
    #endif

    #if defined(_WIN32) || defined(_WIN64)
        system("cls");
    #endif
}
void pause(){
    printf("Press ENTER to continue!\n");		
	char c=getch();
}

void rules(){
	printf("1. You have to destroy your opponent's town before he destroys yours.");
	printf("2. The battlefield is of 10x10 grid size in which you place your towns.");
	printf("3. You can place your towns by entering its orientation, i.e horizontal or vertical.");
	printf("   For horizontal orientation, type 'h' in the orientation option and type 'v' for vertical\n");
	printf("   and its x y coordinates (both separated by a space) where x is the row number and y is the column number\n");
	printf("4. You have a fleet of 4 towns:\n");
	printf("   -- Addersfield (5 units long)\n   -- Beachcastle (4 units long)\n   -- Davenport (3 units long)\n   -- Cherrytown (2 units long)\n");
	printf("5. After placing your towns, you can attack the enemy area.\n");
	printf("   To attack a area, enter its x y coordinate (separated by a space)\n");
	printf("6. Attack hit to the enemy town is denoted by a 'H' and you get an extra turn\n");
	printf("7. Attack miss is denoted by a '*' and your turn ends\n\n");
	pause();
	clear();
}


void vertikal(int x,int y,char tipe[]){
	
}

void horizontal(int x,int y,char tipe[]){
	
}

struct data{
	
};

int main(){
	system("color F1");
	char wel[]="Welcome to battLeKtown...\n";
	for(int i=0;i<strlength(wel);i++){
		printf("%c",wel[i]);
		usleep(1000);
	}
	sleep(1.5);
	clear();
	system("color F0");
	char choose;
	do{
	clear();
	printf("[1] Play Game\n[2] Game Rules\n[3] Exit\n");choose=getch();	
	switch(choose){
		case '1':{
			clear();
			char orien;
			int x,y;
			int beach=1;
			do{
				switch(beach){
					case 1:{
						dismap();
						printf("Town Name: Addersfield\nOrientation ['v' or 'h']: ");orien=getch();
						switch(orien){
						case 'v':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						vertikal(x,y,"Addersfield");
						break;
						}
						case 'h':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						horizontal(x,y,"Addersfield");
						break;
						}
						beach++;
				
						}
						break;
					}
					case 2:{
						dismap();
						printf("Town Name: Beachcastle\nOrientation ['v' or 'h']: ");orien=getch();
						switch(orien){
						case 'v':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						vertikal(x,y,"Beachcastle");
						break;
						}
						case 'h':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						horizontal(x,y,"Beachcastle");
						break;
						}
						beach++;
				
						}
						break;
					}
					case 3:{
						dismap();
						printf("Town Name: Cheerytown\nOrientation ['v' or 'h']: ");orien=getch();
						switch(orien){
						case 'v':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						vertikal(x,y,"Cheerytown");
						break;
						}
						case 'h':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						horizontal(x,y,"Cheeytown");
						break;
						}
						beach++;
				
						}
						break;
					}
					case 4:{
						dismap();
						printf("Town Name: Davenport\nOrientation ['v' or 'h']: ");orien=getch();
						switch(orien){
						case 'v':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						vertikal(x,y,"Davenport");
						break;
						}
						case 'h':{
						printf("x and y coordinates [0-9] [0-9]: ");scanf("%d %d",&x,&y);
						horizontal(x,y,"Davenport");
						break;
						}
						beach++;
				
						}
						break;
					}
				}
			}while(beach!=5);
			
//			printf("Beachfield\nOrientation ['v' or 'h']: ");orien=getch();

			break;
		}
		case '2':{
			clear();
			rules();
			break;
		}
	}
	}while(choose!='3');
	
	printf("Wonderful things can be achieved when there is a teamwork, hardwork, and perseverance.\nLK23-2\n");
	getch();
}
