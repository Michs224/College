#include <stdio.h>
#include <string.h>
#include <ctype.h>

int main(){

//    printf("%d\n",x);
    char str[100],strnew[100];
    int T;
    scanf("%d",&T);
    for(int i=0;i<T;i++){
        scanf("%[^\n]",str);
        int n=strlen(str);
        int angka=0,k=0;
        char strdigit[]={NULL};
        char strhuruf[]={NULL};
        for(int j=0;j<n;j++){
            if(isdigit(str[j])){
                int c=j;
                while(isdigit(str[c])){
                    strdigit[k]=str[c];
                    c++;
                    k++;
                }
                k=0;
                j=c;
                angka=atoi(strdigit);

            }
            else if(str[j]=='['){
                int c=j;
                while(str[c]!=']'){
                    strhuruf[k]=str[c];
                    c++;
                    k++;
                }
                k=0;
                j=c;

            }
        }
        
        printf("Case #%d: %s",i+1,)
    }
    return 0;
}
