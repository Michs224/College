#include <stdio.h>

int fibo(int n,int a,int b){
	if(n==0){
		return a;
	}
	else if(n==1){
		return b;
	}
	else return fibo(n-1,a,b)+fibo(n-2,a,b);
	
}

int main(){
	
	int t,n,a,b;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		scanf("%d %d %d",&n,&a,&b);
		int x=fibo(n,a,b);
		printf("Case #%d: %d\n",i+1,x);
	}
	
	return 0;
}
