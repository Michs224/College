#include <stdio.h>

double pow3(double n){
	int y=n;
	if(n==1){
		return 1;
	}
	else if(n==0)return 0;
	else if(n<1) return 0;
	else {
		n/=3;
		return pow3(n);
	}
	
}


int main(){
	int t;
	double n;
	scanf("%d",&t);
	for(int i=0;i<t;i++){
		scanf("%lf",&n);
		int x=pow3(n);
		
		if(x==1){
			printf("Case #%d: True\n",i+1);
		}
		else printf("Case #%d: False\n",i+1);
		
		
	}
	
	return 0;
}
