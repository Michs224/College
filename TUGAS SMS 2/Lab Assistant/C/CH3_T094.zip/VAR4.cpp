#include <stdio.h>

char s[100][100];
int check=0;
void troubleintown(int x,int y,int n){
	if(x<0 || x>n || y<0 || y>n){
		return;
	}

	if(s[x][y]=='#')return;
	if(s[x][y]=='X')check=1;
	
	if(s[x][y]==' '){
		s[x][y]='#';
	}
	troubleintown(x-1,y,n);
	troubleintown(x+1,y,n);
	troubleintown(x,y-1,n);
	troubleintown(x,y+1,n);
	
	
	//	if(s[x][y]=='X' || s[x][y-1]=='X' || s[x+1][y]=='X' || s[x][y+1]=='X'){
//		
//		c=1;
//		return c;
//	}

}


int main(){
	int n;
	scanf("%d",&n);getchar();
	
	for(int i=0;i<n;i++){
		scanf(" %[^\n]",s[i]);
		
	}

//	int check;
	for(int i=0;i<n;i++){
		for(int j=0;j<n;j++){
			if(s[i][j]=='P'){
				troubleintown(i,j,n);
				break;
			}
		}
	}
//	for(int i=0;i<n;i++){
//		for(int j=0;j<n;j++){
//			printf("%c",s[i][j]);
//		}puts("");
//	}
	if(check==1)
		printf("True\n");
	else printf("False\n");
	
	return 0;
}
