#include <stdio.h>
#include <stdlib.h>
#include <ctype.h>
#include <string.h>

struct stack{
	int data;
	struct stack*next;
};

struct stack*top=NULL;

struct stack *push(struct stack *top,int val){
	struct stack *ptr=(struct stack*) malloc(sizeof(struct stack));
//	ptr=top;
	ptr->data=val;
	if(top==NULL){
		ptr->next=NULL;
		top=ptr;
//		top->data=val;
//		top->next=NULL;
	}
	
	else{
		ptr->next=top;
		top=ptr;
	}
	
	return top;
	
}

struct stack *pop(struct stack *top){
	struct stack *ptr=(struct stack*) malloc(sizeof(struct stack));
	ptr=top;
	if(top==NULL){
	}
	else{

	}
	
	return top;
}


int main(){
	char infix[31];
	int hasil;
	scanf("%[^\n]",infix);	
	int n=strlen(infix);
	char tampung[31];
	int angka;
	for(int i=0;i<n;i++){
		if(isdigit(infix[i])){
			int k=0;
			while(!isdigit(infix[i])){
				tampung[k]=infix[i];
				k++;
			}
			i=k;
			angka=atoi(infix);
			
		}
	}	
//	printf("");
	
	return 0;
}
