#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <conio.h>
#include <unistd.h>


struct data{
	char email[101];
	char password[101];
	int money;
	int axeLevel;
	int id;
}player[1000];


void exit(){
	system("cls");
	char exit[30][100]= {"                                              .",
						 "                                             ...",
						 "                                            ..,..",
						 "                                          ....*...",
						 "                                         ..,..*.....",
						 "                                       ....*****,,....",
						 "                                     ..*,**.****,,****..",
						 "                 .....         ..... ...***...*..,***..  .....            ..",
						 "                   ..*,....*,.,*,*,..    ...,*,*,..      .,*,*,.,*,.,..*...",
						 "                    ...,,***...*,*,.  ...,******,.%.. .  ..***...****,...",
						 "                      ..,**.**,......,**,***,,&&(*******......,*,****...",
						 "                       ...*.**..,*******,, &&&*,,**,,,*******..*,,,...",
						 "                        .***,*..,***,,*,&&&&**,*,*,,,**& ***...*,***.",
						 "                        ...... ..,***,&&&&/,,***,&&&&&& ****.  ......",
						 "                          .     ..***&&&&(*,****,*/&&&//,**..     .",
						 "                        ..**,....,**&&&&&%/,,***,,&&&&/*,**,....,**.",
						 "                       .,,,,,,,.,,,&#**,,,,,,,,*&&&&/*,,,,,,,.,,,,,,.",
						 "                      ..,...**.*,*******,,***,&& /*,,********.,*...*..",
						 "                     ....*******......**,**%&(*,,******......***,***...",
						 "                   ....**.***..*,**.   .. ******,**..   ..****..,*..**...",
						 "                 .............**,*,.   .....,***.....   ..**,*.............",
						 "                                 .   ..******.,.,****,..  .",
						 "                                     ..*,*,..**,..****.",
						 "                                        ..******,*..",
						 "                                           ...*..",
						 "                                            ....",
						 "                                             .."};
						 char e[]="                                        Bluejack22-2\n\nWonderful things can be achieved when there is a teamwork, hardwork, and perseverance.";
						 int ee=strlen(e);
						 for(int i=0;i<30;i++){
						 	if(i<29)printf("%s\n",exit[i]);
						 	else printf("%s",exit[i]);
							usleep(10000);
						 }
						for(int i=0;i<ee;i++){
						 	printf("%c",e[i]);
							usleep(10000);
						 }puts("");
						 getch();
    
}


int main(){
	int choose;
	char email[100]={NULL};
	char pass[100]={NULL};
	int money=0,axeLevel=1;
	do{
		system("cls");
		
		printf("MineCrap!#$^&\n1. Login\n2. Register\n3. Exit\n>> ");scanf("%d",&choose);
		switch(choose){
			case 1:{
				int n;
				char *checkemail;
				do{
				printf("Input email [ends with @email.com] : ");getchar();
				scanf("%[^\n]",email);
				n=strlen(email);
				for(int i=n-10;i<n;i++){
					
				}
				checkemail=strstr(email,&email[n-10]);
//				printf("%s",checkemail);
				}while(strcmp(checkemail,"@email.com")!=0 || n-10==0);
				
				int c1=0,c2=0,count=0,inval;
				
				do{
					inval=0;
					printf("Input Password [contain alphanumeric with length between 8 - 15] : ");getchar();
					scanf("%[^\n]",pass);
					n=strlen(pass);
					for(int i=0;i<n;i++){
						if(isalnum(pass[i]))c1=1;
						if(isalnum(pass[i]))c2=1;
						
					}
					
					count=c1+c2;
					if(count==2)inval++;
					if(n>=8 && n<=15)inval++;
					
				}while(inval!=2);
				

				FILE*datas=fopen("Players.txt","a+");
				int jumlah=0;
				while(!feof(datas)){
					fscanf(datas,"%d,%[^,],%[^,],%d,%d\n",&player[jumlah].id,player[jumlah].email,player[jumlah].password,&player[jumlah].money,&player[jumlah].axeLevel);

					
					jumlah++;
				}
				fclose(datas);
				int valid=0;
				for(int i=0;i<jumlah;i++){
					if(strcmp(player[i].email,email)==0 && strcmp(player[i].password,pass)==0){
						valid=1;
					}
				}
				if(valid==0)printf("Failed to logged in, make sure you have prompt the correct credential\n");
				
				else{
//					char username[100]={NULL};
					int choose1;
					char *username=strtok(email,"@");

//					n=strlen(email);
//					for(int i=0;i<n-10;i++){
//						username[i]=email[i];
//					}
					do{
						system("cls");
						printf("Welcome, %s\n",username);
						printf("1. Go to mine\n2. Go to shop\n3. Check leaderboard\n4. Back\n>> "); scanf("%d",&choose1);
						switch(choose1){
							case 1:{
								char a[]="Entering the mine";
								char b[]=". . . . ";
								int aa=strlen(a);
								int bb=strlen(b);

									for(int j=0;j<aa;j++){
										printf("%c",a[j]);
										usleep(1000);
									}
									for(int j=0;j<bb;j++){
										printf("%c",b[j]);
										sleep(1.5);
									}
									

								break;
							}
							
							case 2:{
								
								break;
							}
							
							case 3:{
								
								break;
							}
							
						}
						
						
					}while(choose1!=4);
					char out1[]="Signin out";
					char out2[]=". . . ";
					int o1=strlen(out1);
					int o2=strlen(out2);
					

						for(int j=0;j<o1;j++){
							printf("%c",out1[j]);
							usleep(1000);
						}
						for(int j=0;j<o2;j++){
							printf("%c",out2[j]);
							sleep(1);
						}
									

					
				}
					
				break;
			}
			
			
			case 2:{
				int n;
				char *checkemail;
				do{
				printf("Input email [ends with @email.com] : ");getchar();
				scanf("%[^\n]",email);
				n=strlen(email);
				for(int i=n-10;i<n;i++){
					
				}
				checkemail=strstr(email,&email[n-10]);
				printf("%d\n",n-10);

				}while(strcmp(checkemail,"@email.com")!=0 || n-10==0);
				
				int c1=0,c2=0,count=0,inval;
				do{
					inval=0;
					printf("Input Password [contain alphanumeric with length between 8 - 15] : ");getchar();
					scanf("%[^\n]",pass);
					n=strlen(pass);
					for(int i=0;i<n;i++){
						if(isalnum(pass[i]))c1=1;
						if(isalnum(pass[i]))c2=1;
						
					}
					count=c1+c2;
					if(count==2)inval++;
					if(n>=8 && n<=15)inval++;

				}while(inval!=2);
				FILE*datas=fopen("Players.txt","a+");
				if(datas==NULL)printf("Data NULL\n");
				int jumlah=0;
				
				while(!feof(datas)){
					fscanf(datas,"%d,%[^,],%[^,],%d,%d\n",&player[jumlah].id,player[jumlah].email,player[jumlah].password,&player[jumlah].money,&player[jumlah].axeLevel);

					jumlah++;
				}
				int taken=0;
				for(int i=0;i<jumlah;i++){
					if(strcmp(player[i].email,email)==0){
						taken=1;
						break;
					}
					
				}
				if(taken==1){
				printf("This email is already taken!\n");	
				}
				else{
				fprintf(datas,"%d,%s,%s,%d,%d\n",player[jumlah-1].id+1,email,pass,money,axeLevel);
				fclose(datas);
				printf("Account succesfully created!\n");
				}			
				getch();

				break;
			}
		}
		
	}while(choose!=3);
	exit();
	
	return 0;
}
