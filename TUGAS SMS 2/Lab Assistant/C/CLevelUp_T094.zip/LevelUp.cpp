#include <stdio.h>
#include <string.h>
#include <ctype.h>
#include <stdlib.h>
#include <windows.h>
#include <unistd.h>
#include <conio.h>

struct data{
	char username[100];
	int score;
	int hs;
	
}p[1000];


//void cls(){
//	COORD cursor;
//	cursor.X=0;
//	cursor.Y=0;
//	SetConsoleCursorPosition=SetStdHandle((STD_OUTPUT_HANDLE),cursor);
//}

int main(){
	
	int choose;
	do{
		printf("VLIPS THE CARD\n\n1. Login\n2. Register\n3. Exit\n>> ");scanf("%d",&choose);
		
		switch(choose){
			case 1:{
				int n;
				char user[]={NULL},user1[]={NULL},*user2;
				int count=0;
				do{
				printf("Input username: ");scanf(" %[^\n]",user1);
//				printf("%s\n",user2);
//				user1=strtok(user2," ");
////				strcat(user1,user2);
				n=strlen(user1);
//				printf("%s",user1);
				if(user1[0]>=65 && user1[0]<=91)count++;
				user2=strstr(user1," ");
				strcpy(user,user1);
//				printf("%s\n",user2);
				if(user2[1]!=NULL)count++;

				if(count!=2)printf("Username must starts with capital letter and contain at least two words\n");
				}while(count!=2);
				
				char pass[]={NULL};
				int count1=0,c1=0,c2=0;
				do{
				printf("Password [5 - 10 characters & Alphabet] : ");scanf(" %[^\n]",pass);
				n=strlen(pass);
				if(n>=5 && n<=10)c1=1;
				for(int i=1;i<n;i++){
					if(isdigit(pass[i]))c2=0;
					else c2=1;
				}
				count=c1+c2;
				
				}while(count!=2);
				FILE*datas=fopen("UserData.txt","a+");
				int jlh=0;
				while(!feof){
					fscanf(datas,"%[^#]#%d#%d\n",p[jlh++].username,&p[jlh].score,&p[jlh].hs);	
				}
				int check=0;
				for(int i=0;i<jlh;i++){
					if(strcmp(p[i].username,user)==0)check==1;
					break;
				}
				if(check!=1)printf("Invalid email or password!\n");
			
				break;
			}
			
			
			case 2:{
				int n;
				char user[]={NULL},user1[]={NULL},*user2;
				int count=0;
				
				do{
				printf("Input username: ");scanf(" %[^\n]",user1);getchar();
//				printf("%s\n",user2);
//				user1=strtok(user2," ");
////				strcat(user1,user2);
				n=strlen(user1);
//				printf("%s",user1);
				if(user1[0]>=65 && user1[0]<=91)count++;
//				printf("%s\n",user1);
				user2=strstr(user1," ");
//				printf("%s\n",user1);
				strcpy(user,user1);

//				printf("%s\n",user2);
				if(user2[1]!=NULL)count++;
	
				if(count!=2)printf("Username must starts with capital letter and contain at least two words\n");
				}while(count!=2);
				
				char pass[]={NULL};
				int count1=0,c1=0,c2=0;
				do{
				printf("Password [5 - 10 characters & Alphabet] : ");scanf(" %[^\n]",pass);
//				printf("%s\n",user);
				n=strlen(pass);
				if(n>=5 && n<=10)c1=1;
				for(int i=1;i<n;i++){
					if(isdigit(pass[i]))c2=0;
					else c2=1;
				}
				count=c1+c2;
//				printf("%d\n",count);
				}while(count!=2);
				int score=0,hs=0;
				FILE*datas=fopen("UserData.txt","a+");
//				printf("%s\n",user1);
				fprintf(datas,"%s#%d#%d\n",user,score,hs);
				fclose(datas);
//				system("cls");
				printf("Welcome to the Game\n");
				system("pause");
				int choose1;
				do{
				system("cls");
				printf("VLIPS THE CARD\n");
				printf("1. Play\n2. View Scoreboard\n3. Tutorial\n4. Sign out\n>> ");scanf("%d",choose1);
				switch(choose1){
					case 1:{
						int choosemode;
						do{
						printf("VS 22-2\nCHoose your mode: ");
						printf("1. Easy\n2. Medium\n3. Hard\n4. Impossible\n5. Back");scanf("%d",&choosemode);
						}while(choosemode!=5);

						
						break;
					}
					case 2:{
						
						break;
					}
					case 3:{
						
						break;
					}
				}					
				}while(choose1!=4);

				break;
			}
			
		}
		
		
	}while(choose!=3);
	puts("==============================THANK YOU FOR PLAYING===============================\n");
	puts("Wonderful things can be achieved when there is a teamwork, hardwork, and perseverance\nCreated By VS22-2    :D");
	getch();
}
