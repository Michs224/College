DROP TABLE IF EXISTS TransactionDate
DROP TABLE IF EXISTS MsSupplier
DROP TABLE IF EXISTS MsCity
CREATE TABLE TransactionDate (
	DateName VARCHAR(50),
	ProductName VARCHAR(50),
	Quantity INT

)

SELECT UPPER(LEFT(DateName,4)) DateName, LOWER (ProductName) ProductName, Quantity FROM TransactionDate
WHERE DateName = 'Monday' OR DateName = 'Wednesday' OR DateName = 'Thursday'

INSERT INTO TransactionDate(DateName, ProductName)
VALUES('Monday','Silwolf HSHS ALALA')


CREATE TABLE MsSupplier(
	supplierID VARCHAR(10),
	supplierName VARCHAR(30),
	CONSTRAINT PK_SupplierID PRIMARY KEY(supplierID)
)

CREATE TABLE MsCity(
	cityID CHAR(5),
	cityName VARCHAR(100),
	CONSTRAINT FK_CITYID FOREIGN KEY (cityID)
)


SELECT * FROM MsSupplier
SELECT * FROM MsCity

ALTER TABLE MsSupplier ADD supplierCityID CHAR(5)

INSERT INTO MsSupplier
VALUES('SP010','GunplaShop','CI001')

UPDATE MsSupplier
SET supplierCityID = 'CI001'
WHERE CHARINDEX(' ', supplierName) > 0;