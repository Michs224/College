USE Jallhara

SELECT * FROM MsTicket
SELECT * FROM MsCustomer

--1
SELECT CustomerName, TicketName, CustomerAddress, TicketPrice
FROM MsCustomer c
FULL JOIN MsTicket t ON c.CustomerID = t.TicketTypeID
WHERE c.CustomerAddress LIKE '%e' AND YEAR(CURRENT_TIMESTAMP) - YEAR(c.CustomerDOB) > 15;

--2

CREATE NONCLUSTERED INDEX IX_MsTicket_TicketName ON MsTicket(TicketName)

--3
SELECT TicketID, TicketName, CONCAT('Rp.', TicketPrice,',00') AS TicketPrice
FROM MsTicket
WHERE LEN(TicketName)�<=�20;


--4
SELECT CONCAT('Ticket ', RIGHT('000', 3 - LEN(REPLACE(TicketID, 'TC', ''))) + REPLACE(TicketID, 'TC', '')) AS TicketID,
       TicketName,
       FORMAT(TicketDate, 'dd MMM yy') AS TicketDate,
       TicketPrice
FROM MsTicket
WHERE YEAR(TicketDate)�=�2022;


--5
CREATE VIEW Senior_Female_Staff AS
SELECT MsStaff.StaffID, CONCAT('Mr./Mrs. ', UPPER(StaffName)) AS StaffName, StaffAddress, LEFT(StaffWorkingShift, 1) AS StaffWorkingShift
FROM MsStaff
JOIN TransactionHeader ON MsStaff.StaffID = TransactionHeader.StaffID
JOIN TransactionDetail ON TransactionHeader.TransactionID= TransactionDetail.TransactionID
WHERE StaffGender = 'Female' AND Quantity >= 15;

DROP VIEW Senior_Female_Staff

SELECT * FROM TransactionHeader
SELECT * FROM TransactionDetail

--6
SELECT th.TransactionID, TransactionDate,CustomerName,TicketName, YEAR(CURRENT_TIMESTAMP)-YEAR(CustomerDOB) AS CustomerAge
FROM TransactionHeader th
JOIN TransactionDetail td ON th.TransactionID= td.TransactionID
JOIN MsStaff ms ON ms.StaffID= th.StaffID
JOIN MsCustomer mc ON mc.CustomerID=th.CustomerID
JOIN MsTicket mt ON mt.TicketID=td.TicketID
WHERE MS.StaffID IN ('SF003', 'SF008');

--7
SELECT DISTINCT th.TransactionID
FROM TransactionHeader th
JOIN TransactionDetail td ON td.TransactionID=th.TransactionID
WHERE DAY(TransactionDate) >= 15;

--8
SELECT CustomerName, REPLACE(ms.StaffID,'SF','Staff ') AS StaffID, YEAR(CURRENT_TIMESTAMP)-YEAR(CustomerDOB) AS CustomerAge,TicketName,CONCAT('Rp.',Quantity*TicketPrice,',00') AS TotalTicketPrice
FROM TransactionHeader th
JOIN MsStaff ms ON ms.StaffID=th.StaffID
JOIN TransactionDetail td ON td.TransactionID=th.TransactionID
JOIN MsTicket mt ON mt.TicketID=td.TicketID
JOIN MsCustomer mc ON mc.CustomerID=th.CustomerID
WHERE Quantity <15 AND MONTH(StaffDOB)<6

