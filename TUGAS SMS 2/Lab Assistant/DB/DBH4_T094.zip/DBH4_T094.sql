USE kokumEA

--1

SELECT MS.StaffName,COUNT(*) AS [Transaction Amount]
FROM TransactionHeader th
JOIN MsStaff MS ON MS.StaffID=th.StaffID
JOIN TransactionDetail td ON td.TransactionID=TH.TransactionID
WHERE MONTH(th.TransactionDate)=11
GROUP BY MS.StaffName

--2
SELECT UPPER(MMT.MembershipTypeName) [Membership Type], COUNT(*) [Customer]
FROM MsMembershipType MMT
JOIN MsCustomer MC ON MC.MembershipTypeID=MMT.MembershipTypeID
WHERE MembershipTypeName='silver'
GROUP BY MMT.MembershipTypeName

--3
SELECT UPPER(CustomerName) [Customer Name],CONCAT('Rp ',SUM(DrinkPrice*Quantity),',-') [Total Price]
FROM TransactionHeader th
JOIN MsCustomer mc ON mc.CustomerID=th.CustomerID
JOIN TransactionDetail td ON td.TransactionID=th.TransactionID
JOIN MsDrink md ON md.DrinkID=td.DrinkID
JOIN MsTopping mt ON mt.ToppingID= md.ToppingID
GROUP BY CustomerName
ORDER BY [Total Price]  ASC

--4
SELECT md.DrinkID [Drink ID],DrinkName [Drink Name], AVG(Quantity)[Average Quantity],DrinkPrice [Price]
FROM TransactionHeader th
JOIN TransactionDetail td ON td.TransactionID=th.TransactionID
JOIN MsDrink md ON md.DrinkID=td.DrinkID
WHERE DrinkName LIKE '%Tea'
GROUP BY md.DrinkID,DrinkName,DrinkPrice

--5
SELECT LEFT(ms.StaffName, CHARINDEX(' ', ms.StaffName) - 1) AS [Staff Name],
       CONCAT(SUM(td.Quantity), ' cups') AS [Total Drink Sold]
FROM MsStaff ms
JOIN TransactionHeader th ON ms.StaffID = th.StaffID
JOIN TransactionDetail td ON TH.TransactionID = td.TransactionID
GROUP BY StaffName;

-- 6
SELECT REPLACE(mc.CustomerID, 'CU', 'Customer ') AS [Customer ID],
LEFT(mc.CustomerName, CHARINDEX(' ', mc.CustomerName) - 1) AS [Customer First Name],
SUBSTRING(mc.CustomerName, CHARINDEX(' ', mc.CustomerName) + 1, LEN(mc.CustomerName)) AS [Customer Last Name],
CONCAT('Rp ', SUM((md.DrinkPrice + mt.ToppingPrice) * td.Quantity), ',-') AS [Total Expense]
FROM MsCustomer mc
JOIN TransactionHeader th ON mc.CustomerID = th.CustomerID
JOIN TransactionDetail td ON th.TransactionID = td.TransactionID
JOIN MsDrink md ON td.DrinkID = md.DrinkID
JOIN MsTopping mt ON md.ToppingID = mt.ToppingID
WHERE mc.CustomerGender = 'Male'
GROUP BY mc.CustomerID, mc.CustomerName
ORDER BY [Total Expense] DESC;

--7
SELECT md.DrinkID AS [Drink ID],
md.DrinkName AS [Drink Name],
mt.ToppingName AS Topping,
MAX(td.Quantity) AS [Maximum Quantity],
CONCAT('Rp ', md.DrinkPrice, ',-') AS Price
FROM MsDrink md
LEFT JOIN MsTopping mt ON md.ToppingID = mt.ToppingID
LEFT JOIN TransactionDetail td ON md.DrinkID = td.DrinkID
WHERE md.DrinkName LIKE '%Macchiato%'
GROUP BY md.DrinkID, md.DrinkName, mt.ToppingName, md.DrinkPrice
ORDER BY [Maximum Quantity] DESC;

-- 8
SELECT CONCAT(mt.MembershipTypeName, ' Member') AS [Membership Type],
COUNT(*) AS [Transaction]
FROM MsMembershipType mt
JOIN MsCustomer mc ON MT.MembershipTypeID = mc.MembershipTypeID
JOIN TransactionHeader th ON mc.CustomerID = th.CustomerID
JOIN TransactionDetail td ON th.TransactionID = td.TransactionID
WHERE DAY(th.TransactionDate) > 15 AND mc.CustomerGender = 'Male'
GROUP BY mt.MembershipTypeName

-- 9
	--SELECT TransactionID [Transaction ID],TransactionDate [Transaction Date],StaffID [Staff ID],LEFT(StaffName, CHARINDEX(' ', StaffName) - 1) [Staff Name], REVERSE(SUBSTRING(REVERSE(StaffAddress), 1, CHARINDEX(' ', REVERSE(StaffAddress)) - 1)) [Staff Address],SUM(Quantity) [Tea Total Quantity]
	--FROM TransactionHeader th
	--WHERE DrinkName LIKE '% Tea%'AND LEFT(StaffAddress LIKE ' %'


-- 10
SELECT REPLACE(st.StaffID, 'ST', 'Staff ') AS [Staff ID],
st.StaffName AS [Staff Name],
DATEDIFF(YEAR, st.StaffDOB, '2023-03-03') AS [Staff Age],
mc.CustomerName AS [Customer Name],
DATEDIFF(YEAR, mc.CustomerDOB, '2023-03-03') AS [Customer Age],
SUM(td.Quantity) AS [Total Quantity]
FROM MsStaff st
JOIN TransactionHeader th ON st.StaffID = th.StaffID
JOIN TransactionDetail td ON th.TransactionID = td.TransactionID
JOIN MsCustomer mc ON th.CustomerID = mc.CustomerID
JOIN MsDrink md ON td.DrinkID = md.DrinkID
JOIN MsTopping mt ON md.ToppingID = mt.ToppingID
WHERE 
	md.DrinkName LIKE '%Tea'
	AND mt.ToppingName LIKE '% Jelly'
GROUP BY st.StaffID, st.StaffName, st.StaffDOB, mc.CustomerName, mc.CustomerDOB
ORDER BY�[Staff�ID]�ASC;