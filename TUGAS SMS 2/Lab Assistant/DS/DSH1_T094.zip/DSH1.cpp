#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <conio.h>
#include <stdbool.h>


struct Todo{
	char task[100];
	int hour;
	int minutes;
	struct Todo*next;
};

struct node{
	char todoname[100];
	struct Todo*todo=NULL;
	struct node *next;
};

struct node*head=NULL;
//struct todo*headd=NULL;

void entercontinue(){
	printf("Enter to Continue...");getch();
}

void insertbegin(char data[100]){
	struct node*temp=(struct node*)malloc(sizeof(struct node));
	strcpy(temp->todoname,data);
	temp->next=NULL;
	
	if(head==NULL){
		head=temp;
	}
	else{
		temp->next=head;
		head=temp;
	}
	
}

void deletebebas(int index){
	struct node*temp=(struct node*)malloc(sizeof(struct node));
	
//	if(head==NULL){
//		puts("NULL");
//		
//	}
	if(index==1){
	temp=head;
	head=head->next;
	free(temp);
	}
	else {
		int jlh=1;
		struct node*ptr=(struct node*)malloc(sizeof(struct node));
		ptr=head;
		struct node*pre=(struct node*)malloc(sizeof(struct node));
		
		while(ptr!=NULL){
			if(jlh==index){
				pre->next=ptr->next;
				return;
			}
			pre=ptr;
			ptr=ptr->next;
			jlh++;
		}
			
		puts("Data tidak ditemukan");
	}
	
}

void display1(){
	puts("         _                   _               _                 _               _                _");
	puts("        /\\ \\     _          /\\ \\            / /\\              /\\ \\            /\\ \\             /\\ \\     _");
	puts("       /  \\ \\   /\\_\\       /  \\ \\          / /  \\            /  \\ \\          /  \\ \\           /  \\ \\   /\\_\\ ");
	puts("      / /\\ \\ \\/ / /      / /\\ \\ \\        / / /\\ \\_        / /\\ \\ \\        / /\\ \\ \\         / /\\ \\ \\_/ / /");
	puts("     / / /\\ \\___/ /      / / /\\ \\ \\      / / /\\ \\___\\      / / /\\ \\_\\      / / /\\ \\ \\       / / /\\ \\___/ /");
	puts("    / / /  \\/___/      / / /  \\ \\_\\     \\ \\ \\ \\/___/     / /_/ \\/_/     / / /  \\ \\_\\     / / /  \\/____/");
	puts("   / / /    / / /      / / /   / / /      \\ \\ \\          / /____/\\       / / /   / / /    / / /    / / /");
	puts("  / / /    / / /      / / /   / / /   _    \\ \\ \\        / /\\____\\/      / / /   / / /    / / /    / / /");
	puts(" / / /    / / /      / / /__/ / /   /_/\\__/ / /       / / /_____     / / /___/ / /    / / /    / / /");
	puts("/ / /    / / /      / / /____\\/ /    \\ \\/___/ /       / / /_______\\   / / /____\\/ /    / / /    / / /");
	puts("\\/_/     \\/_/       \\/_________/      \\_____\\/        \\/__________/   \\/_________/     \\/_/ ����\\/_/\n");
	printf("1. Manage Todo List\n2. View All Todo List\n0. Exit\n");
	
}

void display2(){
	struct node*temp=head;
	
	temp=head;
	printf("+=======+\n");
	printf("| TO DO |\n");
	printf("+=======+\n");
	int i=1;
	while(temp!=NULL){
		printf("%d  %s\n",i++,temp->todoname);
		temp=temp->next;
	}	puts("");	
	

	
}

bool checklearning(char newtodo[100]){
	
	if(strcmp(newtodo,"Learning")==0)return true;
	else return false;
	
}

void Addnewtodo(){
	char newtodo[100]={NULL};
	char *token,newtodoo[100];
	
	do{
	printf("Input New Todo [Name More than 3 Characters]: ");fflush(stdin);gets(newtodo);	
	printf("%s\n",newtodo);
	strcpy(newtodoo,newtodo);
	token=strtok(newtodo," ");
	}while(strlen(newtodoo)<3 || !checklearning(token));

	insertbegin(newtodoo);
	
}

int jumlah(){
		struct node*temp=head;
		int jlh=0;
		while(temp!=NULL){
			jlh++;
			temp=temp->next;
		}
		return jlh;
		
}

void Deletetodo(){
	struct node*temp=head;
	temp=head;
		int index;
	if(head==NULL){
		puts("Insert New Task First");
	}
	
	else{
	display2();	
	int jlh=jumlah();

	do{
		printf("Select Index To Delete [1..%d]: ",jlh);scanf("%d",&index);
	}while(index <1 || index>jlh);	
	}
	fflush(stdin);
	entercontinue();
	
	deletebebas(index);
}

void display3(){
	struct node*temp=head;
	temp=head;
	printf("+=======+\n");
	printf("| TO DO |\n");
	printf("+=======+\n");	

	if(head==NULL){
		puts("There's no Data in Todo");
	}
	else{
	int i=1;
	while(temp!=NULL){
		printf("-- %s --\n",temp->todoname);
		temp=temp->next;
	}puts("");		
	}

	
	printf("1. Add New Todo\n2. Manage Todo\n3. Delete Todo\n0. Exit\n");
	
}
	


void Managetodolist(){
	int choose;
	do{system("cls");
		display3();
		printf(">> ");scanf("%d",&choose);
		switch(choose){
			case 1:{
				Addnewtodo();
				entercontinue();
				system("cls");
				break;
			}
			case 2:{
//				Managetodo();
				entercontinue();
				system("cls");
				break;
			}
			case 3:{
				Deletetodo();
				entercontinue();
				system("cls");
				break;
			}
		}
		
	}while(choose !=0);
	 
	
	
}


void Viewalltodolist(){
	struct node*temp=head;
	
	temp=head;

	if(head==NULL){
		puts("There's No ToDo List!");
	}
	else{
	printf("+=======+");
	printf("| TO DO |");
	printf("+=======+");
	int i=1;
	while(temp!=NULL){
		printf("%s\n---------------\n",temp->todoname);
		struct Todo*temp1=head->todo;
		if(temp1==NULL){
			printf("Todo List is Empty!\n");
		}
		else{
			while(temp1!=NULL){
				printf("- %s [ %d hours %d minutes ]",temp1->task,temp1->hour,temp1->minutes);
				temp1=temp1->next;
			}
		}
		
		temp1=temp1->next;
	}		
	}

	
}

int main(){
	int choose;
	
	do{
		display1();
		printf(">> ");scanf("%d",&choose);
		switch(choose){
			case 1:{
				Managetodolist();
				break;
			}
			case 2:{
				Viewalltodolist();
				break;
			}

		}
		
		
	}while(choose!=0);
	
	return 0;
}
