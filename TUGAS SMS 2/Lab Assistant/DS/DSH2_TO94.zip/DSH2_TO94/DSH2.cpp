#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <conio.h>
#include <ctype.h>


struct node{
	char title[100],author[100],genre[100];
	double rating;
	int chapter,price;
	struct node*next,*prev;
};

struct tamp{
	char title[100],author[100],genre[100];
	double rating;
	int chapter,price;
}tampung[1000];

node*data=NULL,*tail=NULL;

struct data{
	char email[100];
	char password[100];
	
}input[10];

void insertdep(char title[100],char author[100],char genre[100],double rating, int chapter,int price){
	struct node*newnode=(struct node*)malloc(sizeof(struct node));
	
	strcpy(newnode->title,title);
	strcpy(newnode->author,author);
	strcpy(newnode->genre,genre);
	newnode->rating=rating;
	newnode->chapter=chapter;
	newnode->price=price;
	
	if(data==NULL){
		newnode->prev=NULL;
		newnode->next=NULL;
		data=newnode;
		tail=newnode;
	}
	
	else{
		newnode->next=data;
		newnode->prev=NULL;
		data->prev=newnode;
		data=newnode;
	}
	
}

bool checkavailable(char email[100]){
	FILE*DATA=fopen("user.txt","a+");
	int i=0;
	while(!feof(DATA)){
		fscanf(DATA,"%[^,],%[^\n]\n",input[i].email,input[i].password);
		if(strcmp(email,input[i].email)==0){
			fclose(DATA);
			return true;
		}
		i++;
	}
	fclose(DATA);
	return false;
	
}

bool check_com(char email[100]){
	char tamp[100]={NULL};
	int i=strlen(email)-10;
	int j=0;
	while(email[i]!=NULL){
		tamp[j]=email[i];
		i++;
		j++;
	}
	if(strcmp(tamp,"@gmail.com")==0 || strcmp(tamp,"@yahoo.com")==0)return true;
	else return false;
	
}
bool check_alphanum(char pass[100]){
	
	int check1=0,check2=0;
	int i=0;
	while(pass[i]!=NULL){
		if(isalnum(pass[i]))check1=1;
		if(isdigit(pass[i]))check2=1;
		i++;
		
	}
	if(check1==1 && check2==1)	return true;
	else return false;
}

void entercontinue(){
	printf("Press enter to continue...");getchar();
}

void displayadmin(){
	printf("MangaShop 221\n");
	printf("=============\n");
	printf("1. Add Manga\n2. Update manga\n3. Delete manga\n4. Manga list\n5. Process order\n6. View order\n7. Logout\n>> ");
	
}

bool checkavailtitle(char title[100]){
	struct node*temp=data;
//	FILE*manga=fopen("manga.txt","a+");

	while(temp!=NULL){
		if(strcmp(title,temp->title)==0)return true;
		temp=temp->next;
	}
	return false;
	
}

void addmanga(){
	char title[100],author[100],genre[100];
	double rating;
	int chapter,price;
	
	do{
		printf("Enter manga title (10 - 50 characters, 0 to cancel): ");getchar();gets(title);
		if(strcmp(title,"0")==0)return;
	}while(!checkavailtitle(title) || strlen(title)<10 || strlen(title)>50);
	
	do{
		printf("Enter manga author (5 - 50 characters, 0 to cancel): ");getchar();gets(author);
		if(strcmp(author,"0")==0)return;
	}while(strlen(author)<5 || strlen(author)>50);
	
	do{
		printf("Enter manga rating (0.1 - 5.0, 0 to cancel): ");getchar();scanf("%d",&rating);
	}while(rating<0.1 || rating > 5.0);
	
	do{
		printf("Enter manga genre (action, horror, romance, shounen, seinen [case sensitive], to cancel): ");getchar();gets(genre);
	}while(strcmp(genre,"action")!=0 && strcmp(genre,"horror")!=0 && strcmp(genre,"romance")!=0 || strcmp(genre,"shounen")!=0 || strcmp(genre,"seinen")!=0);
	
	do{
		printf("Enter manga chapter (min 1, 0 to cancel): ");getchar();scanf("%d",&chapter);
	}while(chapter<1);
	
	do{
		printf("Enter manga price (min 10000 max 1000000, 0 to cancel): ");getchar();scanf("%d",&price);
	}while(price<10000 || price > 1000000);
	
	
	insertdep(title,author,genre,rating,chapter,price);
//	inserttofile(title,author,genre,rating,chapter,price);
	printf("Succesfuly add a new manga\n");
	entercontinue();
}

void displaymanga(){
	
	
}

void displaycustomer(){
	
}

void adminmenu(){
	
	int choose;
	do{
		system("cls");
		displayadmin();
		scanf("%d",&choose);
		
		switch(choose){
			
			case 1:{
				addmanga();
				break;
			}
			case 2:{
				
				break;
			}
			case 3:{
				
				break;
			}
			case 4:{
				
				break;
			}
			case 5:{
				
				break;
			}
			case 6:{
				
				break;
			}
		}
		
	}while(choose !=7);
	
}

void login(){
	char email[100];
	char pass[100];
	do{
		printf("Enter your email (enter 0 to return): ");getchar();
		gets(email);
		if(strcmp(email,"0")==0)return;
		fflush(stdin);
		
		printf("Enter your password (enter 0 to return): ");getchar();
		gets(pass);
		if(strcmp(pass,"0")==0)return;
		fflush(stdin);
		if(!checkavailable(email) || email[0]=='@' || email[strlen(email)]=='@' || !check_com(email) || !check_alphanum(pass) || strlen(pass)<8 || strlen(pass)>20)printf("Wrong credentials\n");	
	}while(!checkavailable(email) || email[0]=='@' || email[strlen(email)]=='@' || !check_com(email) || !check_alphanum(pass) || strlen(pass)<8 || strlen(pass)>20);
	entercontinue();
	
	adminmenu();
	
	
}

//void regist(){
//	
//	
//	insertusertofile(email,password);
//}

void displaymenu(){
	
	printf("MangaShop 221\n");
	printf("=============\n");
	
	printf("1. Login\n2. Register\n3. Exit\n>> ");
	
}

int main(){
	int choose;
	
	do{
		system("cls");
		displaymenu();
		scanf("%d",&choose);
		
		switch(choose){
		case 1:{
			login();
			
			break;
		}
		case 2:{
//			regist();
			break;
		}			
		}

		
		
	}while(choose!=3);
	
	
	return 0;
}
