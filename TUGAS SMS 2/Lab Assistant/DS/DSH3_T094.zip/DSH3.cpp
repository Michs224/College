#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <time.h>
#include <ctype.h>

struct node{
	char seednames[100],sources[100],id[6];
	int quality,price;
	struct node*next;
};

node*head[1000]={NULL};

void displaymenu(){
	printf("\n __                   __                  /--\\      ,\n");
	printf("|  |                 |  |                <>^  L____/|\n");
	printf("|  |--.-----.--.--.--|  |.---.-.--.--.    `) /`   , /\n");
	printf("|     |  -__|  |  |  _  ||  _  |  |  |     \\ `---' /\n");
	printf("|__|__|_____|___  |_____||___._|___  |      `'"";\\))`\n");
	printf("            |_____|            |_____|        _/_Y\n");
	
	printf("1. Buy seed  plant\n2. View Inventory\n3. Plant and harvest\n4. Exit\n>> ");
}

struct node*insert(int key,char id[6],char seedname[100],char source[100],int quality,int price){
	struct node*temp=(struct node*)malloc(sizeof(struct node));
	struct node*last=(struct node*)malloc(sizeof(struct node));
	last=head[key];
	
	strcpy(temp->sources,source);
		strcpy(temp->seednames,seedname);
			strcpy(temp->id,id);
			temp->quality=quality;
			temp->price=price;
	temp->next=NULL;
	
	if(head[key]==NULL){
		head[key]=temp;
	}
	else{
		while(last->next!=NULL){
			last=last->next;
		}
		last->next=temp;
		
	}
	
	return head[key];
	
}

void entercontinue(){
	printf("Press enter to continue...");getchar();
}

bool checkseedname(char seedname[100]){
	int i=0;
	int check1=0;
	if(seedname[0]!=' ' && seedname[0]!=NULL)check1=1;
	while(seedname[i]!=NULL){
		if(seedname[i]!=' ' && seedname[i]!=NULL){
			i++;
			while(seedname[i]!=NULL){
				if(seedname[i]==' '){
					i++;
					if(seedname[i]!=' ' && seedname[i]!=NULL)return true;
					else return false;
				}
			}
		}
		i++;
	}
	return false;
	
	
	
}

void Buyseed(){
	static int coin=10000;
	
	printf("Your money: %d",coin);
	char seedname[100];
	do{
		printf("Input seed name [min 2 words]: ");getchar();gets(seedname);
		
	}while(!checkseedname(seedname));
	char source[100];
	do{
		printf("Input source [forest|field] (case insensitive): ");getchar();gets(source);
	}while(strcmpi(source,"forest")!=0 && strcmpi(source,"field")!=0);
	
	int quality;
	if(strcmpi(source,"forest")==0){
		quality=rand()%51;
	}
	else{
		quality=(rand()%50)+51;
	}
	int price=quality*(94 + ((rand()%30)+10) + 1000);
	
	char id[6]={NULL};
	
	for(int i=0;i<2;i++){
		id[i]=toupper(source[i]);
	}
	for(int i=0;i<3;i++){
		int x;
		char num[2]={NULL};
		x=rand()%10;
		itoa(x,num,10);
		
		strcat(id,num);
	}
	
	coin-=price;
	int key=0;
	for(int i=2;i<5;i++){
		key+=id[i]-48;
	}
	insert(key,id,seedname,source,quality,price);
}

int main(){
	srand(time(0));
	int choose;
	displaymenu();
	do{
		
		system("cls");
		displaymenu();
		scanf("%d",&choose);
		
		switch(choose){
			case 1:{
				Buyseed();
				break;
			}
			case 2:{
//				Viewinventory();
				break;
			}
			case 3:{
//				PlandandHarvest();
				break;
			}
		}
		
		
	}while(choose!=4);
	
	
	return 0;
}
