#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <stdbool.h>
#include <conio.h>
#include <time.h>

struct nodeadmin{
	char Id[10],icenames[100],types[100];
	int prices;
	struct nodeadmin*next;
};

struct nodeuser{
	char Id[10],icenames[100],types[100];
	int prices,quantity;
	struct nodeuser*next;
};

nodeadmin*headadmin[100]={NULL};
nodeuser*headuser=NULL;

struct User{
	char username[100],password[100],role[10];	
};

void displaymoxue(){
	
	printf("MOxue\n");
	printf("-----\n\n");
	printf("1. Login\n2. Register\n3. Exit\n>> ");
}

void entercontinue(){
	printf("Press [ENTER] to continue!");getchar();
	
}

void usermenu(){
	
	
}

void Showall(){
	system("cls");
//	struct nodeadmin*temp[1000]=(struct nodeadmin*)malloc(sizeof(struct nodeadmin));
//	temp=headadmin;
	if(headadmin==NULL){
		puts("There's no ice cream!");
		return;
	}
	printf("===========================================================\n");
	printf("| ID    | Name                    | Type          | Price |\n");
	printf("===========================================================\n");
	int i=0;
	while(headadmin[i]!=NULL){
		struct nodeadmin*temp2=headadmin[i];
		while(temp2!=NULL){
			printf("| %s | %s | %s | %d |",temp2->Id,temp2->icenames,temp2->types,temp2->prices);
			temp2=temp2->next;
		}
		i++;
	}
	entercontinue();
	
}

bool checkavailablename(char name[100]){

	int i=0;
	int check=0;
	while(headadmin[i]!=NULL){
		struct nodeadmin*temp2=headadmin[i];
		while(temp2!=NULL){
			if(strcmp(name,temp2->icenames)==0)return false;
			temp2=temp2->next;
		}
		i++;
	}
	if(check==0)return true;
	
	
}

void insert(int key,char id[10],char name[100],char type[100],int price){
	
	struct nodeadmin*temp=(struct nodeadmin*)malloc(sizeof(struct nodeadmin));
	strcpy(temp->Id,id);	strcpy(temp->icenames,name);
	strcpy(temp->types,type);
	temp->prices=price;
	temp->next=NULL;
	
	if(headadmin[key]==NULL){
		headadmin[key]=temp;
	}
	else{
		struct nodeadmin*last=headadmin[key];
		while(last->next!=NULL){
			
			last=last->next;
		}
		last->next=temp;
	}
	
}



int hashkey(char name[100]){
	int i=0;
	int key=0;
	while(name[i]!=NULL){
		key+=name[i];
		i++;
	}
	return key/100;
}

void Addicecream(){
	char name[100];
	
	do{
		printf("Ice cream name (Unique): ");getchar();gets(name);fflush(stdin);
		
	}while(!checkavailablename(name));
	
	char type[100];
	do{
		printf("Ice cream type [ Cone | Sundae | Cup ] (Case Sensitive): ");getchar();gets(type);fflush(stdin);
	}while(strcmp(type,"Cone")!=0 && strcmp(type,"Sundae")!=0 && strcmp(type,"Cup")!=0);
	
	int price;
	do{
		printf("Ice cream price [ 10000 - 30000 (Inclusive) and divided by 500 ]: ");getchar();scanf("%d",&price);
	}while(price < 10000 || price >30000 || price/500 != 0);
	
	char id[10]="IC";
	
	for(int i=2;i<5;i++){
		int x;
		x=rand()%10;
		char num[2]={NULL};
		itoa(x,num,10);
		strcat(id,num);
	}
	
	int key=hashkey(name);
	insert(key,id,name,type,price);
	
}

void deleteice(char name[100]){
	struct nodeadmin*temp=(struct nodeadmin*)malloc(sizeof(struct nodeadmin));

	if(headadmin==NULL){
		puts("There's no ice cream!");
		return;
	}
	else if(strcmp(headadmin[0]->icenames,name)==0){
		temp=headadmin[0];
		headadmin[0]=headadmin[0]->next;
		free(temp);
	}
	else{
	int i=1,check=0;
	while(headadmin[i]!=NULL){
		struct nodeadmin*ptr=headadmin[i];
		struct nodeadmin*pre=(struct nodeadmin*)malloc(sizeof(struct nodeadmin));
		while(ptr!=NULL){
//			if(strcmp(ptr->icenames,name)==0 && ptr->next!=NULL){
//				temp=ptr;
//				pre->next=ptr->next;
//				free(temp);
//			}
//			else if(strcmp(ptr->icenames,name)==0 && ptr->next==NULL){
//				temp=ptr;
//				ptr=NULL;
//				free(temp);				
//			}

//			pre=ptr;
//			ptr=ptr->next;
			if(strcmp(ptr->icenames,name)==0){
				temp=ptr;
				pre->next=ptr->next;
				free(temp);
				printf("Ice cream has been deleted!\n");
				return;
			}
		pre=ptr;
		ptr=ptr->next;
		}
		i++;
	}
	if(check==0){
		printf("There's no ice cream to be deleted!\n");
	}
	}

	
}

void Deleteicecream(){
	Showall();
	
	char name[100];
	
	printf("Delete Ice Cream by Name [Choose '0' to cancel] (Case Sensitive): ");getchar();gets(name);fflush(stdin);
	
	deleteice(name);
	entercontinue();
}

void adminmenu(){
	
	int choose;
	
	
	do{
		system("cls");
		printf("MOxue\n");
		printf("1. Show All Ice Cream\n2. Add Ice Cream\n3. Delete Ice Cream\n4. Exit\n>> ");
		scanf("%d",&choose);
		switch(choose){
			case 1:{
				Showall();
				break;
			}
			case 2:{
				Addicecream();
				break;
			}
			case 3:{
				Deleteicecream();
				break;
			}
		}
		
	}while(choose!=4);
	
	
	
}

void savedata(char username[100], char password[100], char role[10]){
	FILE*User=fopen("user.txt","a+");
	
	fprintf(User,"%s#%s#%s\n",username,password,role);
	
	fclose(User);
	
}

void Register(){
	char username[100],password[100],role[10]={NULL};
	do{
		printf("Input name [ 4 - 20 characters (inclusive) ]: ");getchar();gets(username);
		fflush(stdin);
		
	}while(strlen(username)<4 || strlen(username)>20);
	
	do{
		
		printf("Input Password [4 - 12 characters ]: ");getchar();gets(password);fflush(stdin);
	}while(strlen(password)<4 || strlen(username)>20);
	
	strcpy(role,"User");
	
	savedata(username,password,role);
	printf("User has been added\n");
	entercontinue();
}

void Login(){
	char username[100],password[100],role[10]={NULL};
	int check;
	do{
		check=0;
		printf("Username: ");getchar();gets(username);
		fflush(stdin);
		
		printf("Password: ");getchar();gets(password);
		fflush(stdin);
		
		FILE*User=fopen("user.txt","r");
		struct User user;
		while(!feof(User)){
			
			fscanf(User,"%[^#]#%[^#]#%[^\n]\n",user.username,user.password,user.role);
			if(strcmp(username,user.username)==0 && strcmp(password,user.password)==0){
				check=1;
				strcpy(role,user.role);
			}
		}
		fclose(User);
		
	}while(strlen(username)<4 || strlen(username)>20 || check==0);
	
	if(strcmp(role,"Admin")==0)adminmenu();
	else if(strcmp(role,"User")==0)usermenu();
	
	
	
}

int main(){
	int choose;
	srand(time(0));
	do{
		system("cls");
		displaymoxue();
		scanf("%d",&choose);
		switch(choose){
			
			case 1:{
				Login();
				break;
			}
			case 2:{
				Register();
				break;
			}
		}
		
	}while(choose!=3);
	
	
	return 0;
}
