

//Validasi String 2 Kata
// 1.
//    String[] words = str.split(" ");
//    if (words.length != 2) {
//        return false;
//    }
// 2.		do {
//			System.out.print("Input your name [two words]: ");
//			name= scan.nextLine();
//		}while(!name.matches("^[A-Za-z]+\\s[A-Za-z]+$"));

//Validasi Alphanumeric dan Length
//			do {
//			check=0;
//			System.out.println("Input password [Alphanumeric && > 5 character] : ");
//			pass=scan.nextLine();
//			if(pass.matches("^(?=.*[a-zA-Z])(?=.*\\d)[a-zA-Z\\d]+$"))check++;
//			if(pass.length()>5)check++;
//			}while(check!=2);

package JAVAIH1;

import java.util.Scanner;

public class JAVAIH1 {
 static Scanner scan=new Scanner(System.in);
 static int hp=20,attack=2,stamina=10,maxhp=25,maxxp=8,xp=0;
 float evasion=(float) 0.09;

 
 public static void cls() {
     try {
         if (System.getProperty("os.name").contains("Windows")) {
             new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
         } else {
             System.out.print("\033[H\033[2J");
             System.out.flush();
         }
     } catch (Exception e) {
         System.out.println("Clear screen failed: " + e);
     }
 }
 
	public JAVAIH1() {
		// TODO Auto-generated constructor stub
	}
	static void fight(int enemyhealth,int enemyattack) {
		int AR;
		do {
			cls();
			
			System.out.println("Your Turn");
			System.out.println("+=============================+");
			System.out.println("| Your HP    | "+hp+"      |");
			System.out.println("| Your Attack    |"+attack+"      |");
			System.out.println("| Enemy HP    | "+enemyhealth+"      |");
			System.out.println("+=============================+\n");
			System.out.print("1. Attack\n2. Run\n>> ");
			AR=scan.nextInt();
			scan.nextLine();
			switch(AR) {
			case 1:{
				System.out.println("You hitted the enemy with "+attack+" damage!");
				enemyhealth-=attack;
				scan.nextLine();
				break;
			}
			case 2:{
				System.out.println("You Run away!");
				System.out.print("Press enter to continue..");
				scan.nextLine();
				break;
			}
			}
			if(enemyhealth>0) {
			cls();
			System.out.println("Enemy's Turn!");
			System.out.println("-----------------------------");
			System.out.println("Oh no.. you've been hitted "+enemyattack+" damage!");
			hp-=enemyattack;
			System.out.print("Preess enter to continue..");
			scan.nextLine();
			}
			
		}while(enemyhealth>0 && hp >0);
		if(enemyhealth<=0) {
			System.out.println("Congrats! You've defeated the enemy!");
			xp+=8;
			System.out.println("Earned 8 XP");
			System.out.print("Preess enter to continue..");
			scan.nextLine();
		}
		else if(hp<=0) {
			System.out.println("You Died...");
			System.out.print("Preess enter to continue..");
			scan.nextLine();
		}
	}
	
	static void homepage(String name, String mode,int enemyhealth,int enemyattack,int enemyex) {
			int choosegame;	
		do {	
			cls();

		System.out.println("+==========================+");
		System.out.println("| Mode     | "+mode+"      |");
		System.out.println("+==========================+");
		System.out.println("| Username | "+name+"      |");
		System.out.println("+==========================+");
		System.out.println("| Attack   | "+attack+"    |");
		System.out.println("+==========================+");
		System.out.println("| HP/MaxHP | "+hp+"/"+maxhp+"    |");
		System.out.println("+==========================+");
		System.out.println("| XP/MaxHP | "+xp+"/"+maxxp+"     |");
		System.out.println("+==========================+");
		if(mode.equals("Easy"))
		System.out.println("| Level    | 1             |");
		else if(mode.equals("Medium"))
		System.out.println("| Level    | 2             |");	
		else System.out.println("| Level    | 3             |");
		System.out.println("+==========================+");
		System.out.println("| Stamina  | "+stamina+"      |");
		System.out.println("============================");
		System.out.print("1. Fight\n2. Train\n3. Sleep\n4. Exit\n>> ");
		choosegame=scan.nextInt();
		scan.nextLine();

		switch(choosegame) {
		case 1:{
			fight(enemyhealth,enemyattack);
			break;
		}
		case 2:{
//			Train();
			break;
		}
		case 3:{
//			Sleep();
			break;
		}
		
		}
		

		}while(choosegame!=4);	
	}
		
	static void startgame(String name, String mode) {
		switch(mode) {
		case "Easy":{
			int enemyhealth=10,enemyattack=2,enemyex=3;
			homepage(name,mode,enemyhealth,enemyattack,enemyex);
			break;
		}
		case "Medium":{
			int enemyhealth=12,enemyattack=3,enemyex=5;
			homepage(name,mode,enemyhealth,enemyattack,enemyex);
			break;
		}
		case "Hard":{
			int enemyhealth=16,enemyattack=4,enemyex=8;
			homepage(name,mode,enemyhealth,enemyattack,enemyex);
			break;
		}
		
		}
	}
	
	static void play() {
		cls();
		int check;
		String name="";
		Character namee;
		do {
			System.out.print("Input your name [two words]: ");
			name= scan.nextLine();
		}while(!name.matches("^[A-Za-z]+\\s[A-Za-z]+$"));
		
		String mode="";
		do {
			System.out.print("Choose your mode [Easy|Medium|Hard] : ");
			mode=scan.nextLine();
			
		}while(!mode.equals("Easy") && !mode.equals("Medium") && !mode.equals("Hard"));
		
		System.out.println("You choose "+mode+" Mode !");
		System.out.print("Press enter to continue..");
		scan.nextLine();
		startgame(name,mode);
	}
	
	public static void main(String[] args) {
		int choose;
		String name;

		do {
			System.out.print("1. Play\n2. Exit\n>> ");
			choose=scan.nextInt();
			scan.nextLine();
			switch(choose) {
			case 1:{
				play();
				break;
			}
			
			}
		}while(choose!=2);
		
	}

}
