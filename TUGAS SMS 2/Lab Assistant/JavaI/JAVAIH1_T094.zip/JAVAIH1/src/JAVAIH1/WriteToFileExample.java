package JAVAIH1;


import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.UUID;

public class WriteToFileExample {
    public static void main(String[] args) {
        String filename = "data.txt";
        String data = "Contoh data";
        int nextId = 1;

        // Membaca ID terakhir dari file (jika ada)
        try (BufferedReader reader = new BufferedReader(new FileReader("lastId.txt"))) {
            String line;
            while ((line = reader.readLine()) != null) {
                nextId = Integer.parseInt(line);
            }
        } catch (IOException e) {
            System.err.println("Gagal membaca ID terakhir: " + e.getMessage());
        }

        // Menambahkan data baru ke file
        try (BufferedWriter writer = new BufferedWriter(new FileWriter(filename, true))) {
            String line;
            while((line=reader.readLine()) !=null) {
            	String datas[]=line.split(",");
            }
        	UUID id = UUID.randomUUID();
            writer.write(String.format("%d|%s|%s\n", nextId++, id.toString(), data));
            System.out.println("Data telah ditambahkan ke file.");

            // Menyimpan ID terakhir ke file
            try (BufferedWriter lastIdWriter = new BufferedWriter(new FileWriter("lastId.txt"))) {
                lastIdWriter.write(String.valueOf(nextId));
            } catch (IOException e) {
                System.err.println("Gagal menyimpan ID terakhir: " + e.getMessage());
            }

        } catch (IOException e) {
            System.err.println("Gagal menambahkan data ke file: " + e.getMessage());
        }
    }
}