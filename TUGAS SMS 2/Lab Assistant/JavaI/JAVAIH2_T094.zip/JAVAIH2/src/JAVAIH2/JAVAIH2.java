package JAVAIH2;

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;
import java.util.UUID;


public class JAVAIH2 {

	 public static void cls() {
	     try {
	         if (System.getProperty("os.name").contains("Windows")) {
	             new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
	         } else {
	             System.out.print("\033[H\033[2J");
	             System.out.flush();
	         }
	     } catch (Exception e) {
	         System.out.println("Cls failed: " + e);
	     }
	 }
	 
	 static void Admin(String name) {
		 
	 }
	 
	 static void Customer(String name, int money) {
		 
		 
	 }
	 

	 static void Login() {
		 String name=(String) "";
			int check;
			do {
			
			System.out.print("Input username [> 5 characters]: ");
			name=scan.nextLine();
			}while(name.length()<=5);
			String pass="";
			do {
			check=0;
			System.out.println("Input password [Alphanumeric && > 5 character] : ");
			pass=scan.nextLine();
			if(pass.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\\\d]+$"))check++;
			if(pass.length()>5)check++;
			}while(check!=2);
			
			String role="";
			do {
				System.out.println("[Admin/Customer]: ");
				role=scan.nextLine();
			}while(role!="Admin" && role!="Customer");

			List<String> id=new ArrayList<>();
			List<String> username=new ArrayList<>();
			List<String> password=new ArrayList<>();
			List<String> role1=new ArrayList<>();
			int[] moneyArray = new int[1000];
			String filename="Admin.txt";
			String fileName="Customer.txt";			
			int jlh=0;
			if(role.equals("Admin")) {
		      try (BufferedReader reader = new BufferedReader(new FileReader(filename))) {
		            String line;
		         
					while((line=reader.readLine()) !=null) {
		            	String datas[]=line.split(",");
		            	id.add(datas[0]);
		            	username.add(datas[1]);
		            	password.add(datas[2]);
		            	role1.add(datas[3]);
//		            	moneyArray[jlh]=Integer.parseInt(datas[4]);
		            	jlh++;
		            }		            	
		            
		      } catch(Exception e) {
				e.printStackTrace();
			}				
			}
			else {
			      try (BufferedReader reader = new BufferedReader(new FileReader(fileName))) {
			            String line;
			           
						while((line=reader.readLine()) !=null) {
			            	String datas[]=line.split(",");
			            	id.add(datas[0]);
			            	username.add(datas[1]);
			            	password.add(datas[2]);
			            	role1.add(datas[3]);
			            	moneyArray[jlh]=Integer.parseInt(datas[4]);
			            	jlh++;
			            }		            	
			            
			      } catch(Exception e) {
					e.printStackTrace();
				}					
			}

		 int valid=0;
		 int i;
//		 int money1;
		 for(i=0;i<jlh;i++) {
			 if(username.get(i).equals(name)) {
				 if(password.get(i).equals(pass)) {
					 if(role1.get(i).equals(role))valid=1;
				 }
			 }
		 }
		 if(valid==0) {
			 System.out.println("Login failed, make sure you have input the correct credential!");
			 System.out.print("Press enter to continue");scan.nextLine();
		 }
		 else {
			 switch(role) {
			 
			 case "Admin":{
				 Admin(name);
				 break;
			 }
			 case "Customer":{
				 Customer(name,moneyArray[i]);
				 break;
			 }
			 }
		 }
		
	 
	 }
	 
	static int money=0;
	static void Register() {
		String name=(String) "";
		int check;
		do {
		
		System.out.print("Input username [> 5 characters]: ");
		name=scan.nextLine();
		}while(name.length()<=5);
		String pass="";
		do {
		check=0;
		System.out.print("Input password [Alphanumeric && > 5 character] : ");
		pass=scan.nextLine();
		if(pass.matches("^(?=.*[A-Za-z])(?=.*\\d)[A-Za-z\\d]+$"))check++;
		if(pass.length()>5)check++;
		}while(check!=2);
		
		String role="";
		do {
			System.out.print("[Admin/Customer]: ");
			role=scan.nextLine();
		}while(!role.equals("Admin") && !role.equals("Customer"));
		String filename="Admin.txt";
		String fileName="Customer.txt";
		
		if(role.equals("Admin")) {
		try(BufferedWriter writer =new BufferedWriter(new FileWriter(filename,true))){
			 UUID id = UUID.randomUUID();
				writer.write(String.format("%s,%s,%s,%s",id.toString(),name,pass,role));
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}			
		}
		
		else {
		try(BufferedWriter writer =new BufferedWriter(new FileWriter(fileName,true))){
			 UUID id = UUID.randomUUID();
				writer.write(String.format("%s,%s,%s,%s",id.toString(),name,pass,role));
			
		}
		catch(Exception e) {
			e.printStackTrace();
		}
		}

	}
	
static Scanner scan=new Scanner(System.in);
	public static void main(String[] args) {

		int choose;
		
		do {
			System.out.println("H&Mc");
			System.out.println("===============================");
			System.out.print("1. Login\n2. Register\n3. Exit\n");
			System.out.print("===============================\n>> ");
			choose=scan.nextInt();
			scan.nextLine();
			
			switch(choose) {
			
			case 1:{
				Login();
				break;
			}
			case 2:{
				Register();
				break;
			}
			
			
			}
		}while(choose!=3);
	}

}
