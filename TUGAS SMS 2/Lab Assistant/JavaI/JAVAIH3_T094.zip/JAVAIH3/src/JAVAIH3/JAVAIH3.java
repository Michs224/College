package JAVAIH3;

import java.io.BufferedWriter;
import java.io.BufferedReader;
import java.io.FileWriter;
import java.io.FileReader;
import java.util.ArrayList;
import java.util.Scanner;




public class JAVAIH3 {
	static void cls() {
	    try {
	        if (System.getProperty("os.name").contains("Windows")) {
	            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
	        } else {
	            System.out.print("\033[H\033[2J");
	            System.out.flush();
	        }
	    } catch (Exception e) {
	        System.out.println("Cls failed: " + e);
	    }
	}
	
	static void Delete() {
		cls();
		ArrayList<String> foodname=new ArrayList<>();
		ArrayList<String> foodtype=new ArrayList<>();
		Integer price[]=new Integer[1000];
		Integer quantity[]=new Integer[1000];

		int jlh=0;
		try(BufferedReader reader= new BufferedReader(new FileReader("foodmaterial.txt"))){
			String line;
			int i=0;
			while((line=reader.readLine())!=null) {
				String data[]=line.split("#");
				foodname.add(data[0]);
				foodtype.add(data[1]);
				price[i]=Integer.parseInt(data[2]);
				quantity[i]=Integer.parseInt(data[3]);
				jlh++;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Current Product");
		System.out.println("======================================================================================");
		System.out.println("| No | Food Material Name | Food Type     | Food Price | Food Quantity |");
		System.out.println("======================================================================================");
		int no=1;
		for(int i=0;i<jlh;i++) {
			System.out.println("| "+no+"  | "+foodname.get(i)+"        | "+foodtype.get(i)+"      | "+price[i]+"     | "+quantity[i]+"          |");
			no++;
		}
		int chooseproduct;
		System.out.println("======================================================================================");		
		do {
		System.out.println("Choose product [1-"+(jlh+1)+"]: ");
		chooseproduct=scan.nextInt();
		}while(chooseproduct<1 || chooseproduct>20);

		
		String foodName="";
		String foodType="";
		Integer pricee;
		Integer q;
		
		do {
			System.out.print("Food Name [must not empty and unique]: ");
			foodName=scan.nextLine();
		}while(foodName.isEmpty());
		
		do {
			System.out.print("Food Type [Vegetable | Carbohydrat | Fruit | Proten ] [Case Insensitive]: ");
			foodType=scan.nextLine();
		}while(!foodType.equalsIgnoreCase("Vegetable") && !foodType.equalsIgnoreCase("Carbohydrat") && !foodType.equalsIgnoreCase("Fruit") && !foodType.equalsIgnoreCase("Protein"));
		
		do {
			System.out.print("Price [min. 2000]: ");
			pricee=scan.nextInt();
			scan.nextLine();
		}while(pricee<2000);
		
		do {
			System.out.print("Quantity [more than 0]: ");
			q=scan.nextInt();
			scan.nextLine();
		}while(q<=0);
		foodname.remove(chooseproduct-1);
		foodtype.remove(chooseproduct-1);

		for(int i=chooseproduct-1;i<price.length-1;i++) {
			price[i]=price[i+1];
		}
		price[price.length-1]=null;
		
		for(int i=chooseproduct-1;i<quantity.length-1;i++) {
			quantity[i]=quantity[i+1];
		}
		quantity[quantity.length-1]=null;
		
		int i=0;
		try (BufferedWriter writer= new BufferedWriter(new FileWriter("foodmaterial.txt",true))){
			writer.write(String.format("%s#%s#%d#%d", foodname.get(i),foodtype.get(i),price[i],quantity[i]));
			writer.newLine();
			i++;
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Product Deleted!");
		
	}
	
	static void Update() {
		cls();
		ArrayList<String> foodname=new ArrayList<>();
		ArrayList<String> foodtype=new ArrayList<>();
		Integer price[]=new Integer[1000];
		Integer quantity[]=new Integer[1000];

		int jlh=0;
		try(BufferedReader reader= new BufferedReader(new FileReader("foodmaterial.txt"))){
			String line;
			int i=0;
			while((line=reader.readLine())!=null) {
				String data[]=line.split("#");
				foodname.add(data[0]);
				foodtype.add(data[1]);
				price[i]=Integer.parseInt(data[2]);
				quantity[i]=Integer.parseInt(data[3]);
				jlh++;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Current Product");
		System.out.println("======================================================================================");
		System.out.println("| No | Food Material Name | Food Type     | Food Price | Food Quantity |");
		System.out.println("======================================================================================");
		int no=1;
		for(int i=0;i<jlh;i++) {
			System.out.println("| "+no+"  | "+foodname.get(i)+"        | "+foodtype.get(i)+"      | "+price[i]+"     | "+quantity[i]+"          |");
			no++;
		}
		int chooseproduct;
		System.out.println("======================================================================================");		
		do {
		System.out.println("Choose product [1-"+(jlh+1)+"]: ");
		chooseproduct=scan.nextInt();
		}while(chooseproduct<1 || chooseproduct>20);

		
		String foodName="";
		String foodType="";
		Integer pricee;
		Integer q;
		
		do {
			System.out.print("Food Name [must not empty and unique]: ");
			foodName=scan.nextLine();
		}while(foodName.isEmpty());
		
		do {
			System.out.print("Food Type [Vegetable | Carbohydrat | Fruit | Proten ] [Case Insensitive]: ");
			foodType=scan.nextLine();
		}while(!foodType.equalsIgnoreCase("Vegetable") && !foodType.equalsIgnoreCase("Carbohydrat") && !foodType.equalsIgnoreCase("Fruit") && !foodType.equalsIgnoreCase("Protein"));
		
		do {
			System.out.print("Price [min. 2000]: ");
			pricee=scan.nextInt();
			scan.nextLine();
		}while(pricee<2000);
		
		do {
			System.out.print("Quantity [more than 0]: ");
			q=scan.nextInt();
			scan.nextLine();
		}while(q<=0);
		foodname.set(chooseproduct-1, foodName);
		foodtype.set(chooseproduct-1, foodType);
		price[chooseproduct-1]=pricee;
		quantity[chooseproduct-1]=q;
		int i=0;
		try (BufferedWriter writer= new BufferedWriter(new FileWriter("foodmaterial.txt",true))){
			writer.write(String.format("%s#%s#%d#%d", foodname.get(i),foodtype.get(i),price[i],quantity[i]));
			writer.newLine();
			i++;
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Product Updated!");
		
	}
	
	static void Insert() {
		cls();
		ArrayList<String> foodname=new ArrayList<>();
		ArrayList<String> foodtype=new ArrayList<>();
		Integer price[]=new Integer[1000];
		Integer quantity[]=new Integer[1000];
		//ArrayList<Integer> price=new ArrayList<>();
		//ArrayList<Integer> quantity=new ArrayList<>();
		int jlh=0;
		try(BufferedReader reader= new BufferedReader(new FileReader("foodmaterial.txt"))){
			String line;
			int i=0;
			while((line=reader.readLine())!=null) {
				String data[]=line.split("#");
				foodname.add(data[0]);
				foodtype.add(data[1]);
				price[i]=Integer.parseInt(data[2]);
				quantity[i]=Integer.parseInt(data[3]);
				jlh++;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		System.out.println("Current Product");
		System.out.println("======================================================================================");
		System.out.println("| No | Food Material Name | Food Type     | Food Price | Food Quantity |");
		System.out.println("======================================================================================");
		int no=1;
		for(int i=0;i<jlh;i++) {
			System.out.println("| "+no+"  | "+foodname.get(i)+"        | "+foodtype.get(i)+"      | "+price[i]+"     | "+quantity[i]+"          |");
			no++;
		}
		System.out.println("======================================================================================");
		String foodName="";
		String foodType="";
		Integer pricee;
		Integer q;
		
		do {
			System.out.print("Food Name [must not empty and unique]: ");
			foodName=scan.nextLine();
		}while(foodName.isEmpty());
		
		do {
			System.out.print("Food Type [Vegetable | Carbohydrat | Fruit | Proten ] [Case Insensitive]: ");
			foodType=scan.nextLine();
		}while(!foodType.equalsIgnoreCase("Vegetable") && !foodType.equalsIgnoreCase("Carbohydrat") && !foodType.equalsIgnoreCase("Fruit") && !foodType.equalsIgnoreCase("Protein"));
		
		do {
			System.out.print("Price [min. 2000]: ");
			pricee=scan.nextInt();
			scan.nextLine();
		}while(pricee<2000);
		
		do {
			System.out.print("Quantity [more than 0]: ");
			q=scan.nextInt();
			scan.nextLine();
		}while(q<=0);
		
		try (BufferedWriter writer= new BufferedWriter(new FileWriter("foodmaterial.txt",true))){
			writer.write(String.format("%s#%s#%d#%d", foodName,foodType,pricee,q));
			writer.newLine();
		} catch (Exception e) {
			e.printStackTrace();
		}
		System.out.println("Insert Success!");
	
	}
	
	static void Admin(String username) {
		int choose1 = 0;
		do {
			cls();
		System.out.println("maRGet\n\n)");
		System.out.println("Welcome, "+username);
		System.out.print("1. Insert new product\n2. Update product\n3. Delete product\n4. Exit\n>> ");		
		
		switch(choose1) {
		case 1:{
			Insert();
			break;
		}
		case 2:{
			Update();
			break;
		}
		case 3:{
			Delete();
			break;
		}
		}
		}while(choose1!=4);	
	
	}
	
	static void Customer(String username) {
		int choosee2;
		do {
			cls();
			System.out.println("maRGet\nWelcome, "+username+"!");
			System.out.print("1. Shop\n2. Healthy Recommendation\n3. Cart\n4. Exit\n>> ");
			choosee2=scan.nextInt();
			scan.nextLine();
			switch(choosee2) {
			case 1:{
				//Shop();
				break;
			}
			case 2:{
				//HealthyRec();
				break;
			}
			case 3:{
				//Cart();
				break;
			}
			}
		}while(choosee2!=4);
	}
	
	static void Register() {
		String username="";
		do {
		System.out.print("Username ['0' to back]: ");
		username=scan.nextLine();			
		}while(username.isEmpty());
		String pass="";
		do {
			System.out.print("Password ['0' to back]: ");
			pass=scan.nextLine();
		}while(pass.isEmpty());
		
		try (BufferedWriter writer= new BufferedWriter(new FileWriter("credential.txt",true))){
			writer.write(String.format("%s#%s", username,pass));
			writer.newLine();
		} catch (Exception e) {
			e.printStackTrace();
		}
	}
	
static Scanner scan=new Scanner(System.in);
	static void Login() {
		String username="";
		do {
		System.out.print("Username ['0' to back]: ");
		username=scan.nextLine();			
		}while(username.isEmpty());
		String pass="";
		do {
			System.out.print("Password ['0' to back]: ");
			pass=scan.nextLine();
		}while(pass.isEmpty());
		
		
		String role="";
		do {
			System.out.println("[Admin/Customer]: ");
			role=scan.nextLine();
		}while(!role.equals("Admin")&& !role.equals("Customer"));
		
		int jlh=0;
		ArrayList<String> user=new ArrayList<>();
		ArrayList<String> password=new ArrayList<>();
		Object credential;
		try(BufferedReader reader= new BufferedReader(new FileReader("credential.txt"))){
			String line;
			while((line=reader.readLine())!=null) {
				String data[]=line.split("#");
				user.add(data[0]);
				password.add(data[1]);
				jlh++;
			}
		}catch(Exception e) {
			e.printStackTrace();
		}
		int i,valid=0;
		for(i=0;i<jlh;i++) {
			if(user.get(i).equals(username)) {
				if(password.get(i).equals(pass)) {
					valid=1;
				}
			}
		}
		if(valid==0) {
			System.out.println("Invalid Credential!");
		}
		else {
			switch(role) {
			case "Admin":{
				Admin(username);
				break;
			}
			case "Customer":{
				Customer(username);
				break;
			}
			}
		}

	}
	
	public static void main(String[] args) {
		int choose;
		do {
			
			System.out.print("maRGet\n1. Login\n2. Register\n3. Exit\n>> ");
			choose=scan.nextInt();
			scan.nextLine();
			switch(choose) {
			case 1:{
				Login();
				break;
			}
			
			case 2:{
				Register();
				break;
			}
			}
		}while(choose!=3);
	}

}
