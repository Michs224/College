
package JAVAIH4;

import java.io.BufferedReader;
import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Scanner;

public class JAVAIH4 {
	
    static ArrayList<String> name=new ArrayList<>();
    static ArrayList<Integer> quantity=new ArrayList<Integer>();
	static Scanner scan =new Scanner(System.in);
	static void cls() {
	    try {
	        if (System.getProperty("os.name").contains("Windows")) {
	            new ProcessBuilder("cmd", "/c", "cls").inheritIO().start().waitFor();
	        } else {
	            System.out.print("\033[H\033[2J");
	            System.out.flush();
	        }
	    } catch (Exception e) {
	    	e.printStackTrace();
	    }
	}
	
    static void mergedsc(ArrayList<Integer> numbers, int leftIndex, int middleIndex, int rightIndex) {
        int leftSize = middleIndex - leftIndex + 1;
        int rightSize = rightIndex - middleIndex;

        ArrayList<Integer> leftArraynum = new ArrayList<Integer>();
        ArrayList<Integer> rightArraynum = new ArrayList<Integer>();
        ArrayList<String> leftname = new ArrayList<String>();
        ArrayList<String> rightname = new ArrayList<String>();
        for (int i = 0; i < leftSize; i++) {
            leftArraynum.add(numbers.get(leftIndex + i));
            leftname.add(name.get(leftIndex+i));
        }

        for (int j = 0; j < rightSize; j++) {
            rightArraynum.add(numbers.get(middleIndex + 1 + j));
            rightname.add(name.get(middleIndex+1));
        }

        int i = 0;
        int j = 0;
        int k = leftIndex;

        while (i < leftSize && j < rightSize) {
            if (leftArraynum.get(i) >= rightArraynum.get(j)) {
                numbers.set(k, leftArraynum.get(i));
                name.set(k,leftname.get(i));
                i++;
            } else {
                numbers.set(k, rightArraynum.get(j));
                name.set(k, rightname.get(j));
                j++;
            }
            k++;
        }

        while (i < leftSize) {
            numbers.set(k, leftArraynum.get(i));
            name.set(k, leftname.get(i));
            i++;
            k++;
        }

        while (j < rightSize) {
            numbers.set(k, rightArraynum.get(j));
            name.set(k, rightname.get(j));
            j++;
            k++;
        }
    }
	
    static void mergeasc(ArrayList<Integer> numbers, int leftIndex, int middleIndex, int rightIndex) {
        int leftSize = middleIndex - leftIndex + 1;
        int rightSize = rightIndex - middleIndex;

        ArrayList<Integer> leftArraynum = new ArrayList<Integer>();
        ArrayList<Integer> rightArraynum = new ArrayList<Integer>();
        ArrayList<String> leftname = new ArrayList<String>();
        ArrayList<String> rightname = new ArrayList<String>();
        for (int i = 0; i < leftSize; i++) {
            leftArraynum.add(numbers.get(leftIndex + i));
            leftname.add(name.get(leftIndex+i));
        }

        for (int j = 0; j < rightSize; j++) {
            rightArraynum.add(numbers.get(middleIndex + 1 + j));
            rightname.add(name.get(middleIndex+1));
        }

        int i = 0;
        int j = 0;
        int k = leftIndex;

        while (i < leftSize && j < rightSize) {
            if (leftArraynum.get(i) <= rightArraynum.get(j)) {
                numbers.set(k, leftArraynum.get(i));
                name.set(k,leftname.get(i));
                i++;
            } else {
                numbers.set(k, rightArraynum.get(j));
                name.set(k, rightname.get(j));
                j++;
            }
            k++;
        }

        while (i < leftSize) {
            numbers.set(k, leftArraynum.get(i));
            name.set(k, leftname.get(i));
            i++;
            k++;
        }

        while (j < rightSize) {
            numbers.set(k, rightArraynum.get(j));
            name.set(k, rightname.get(j));
            j++;
            k++;
        }
    }
    
    static void nameasc() {
    	
    }
    
    static void namedsc() {
    	
    }
	
	
	
	static void quan(ArrayList<Integer> numbers, int leftIndex, int rightIndex,int tanda) {
	       if (leftIndex < rightIndex) {
	    	   int middleIndex = (leftIndex + rightIndex) / 2;
	    	   if(tanda==1) {
	            
	            quan(numbers, leftIndex, middleIndex,1);
	            quan(numbers, middleIndex + 1, rightIndex,1);
	           
	            mergeasc(numbers, leftIndex, middleIndex, rightIndex);		    		   
	    	   }
	    	   	else {
	            quan(numbers, leftIndex, middleIndex,2);
	            quan(numbers, middleIndex + 1, rightIndex,2);
	           
	            mergedsc(numbers, leftIndex, middleIndex, rightIndex);	
	    	   
	       }    	 
	    		   
	    	   }

	 
	       
		
	}
	
	static void sort() {
		int choosesort;
		
		do {
			cls();
			System.out.println("Sort by");
			System.out.println("1. Name Ascendingly\n2. Name Descendingly\n3. Quantity Ascendingly\n4. Quantity Descendingly\n0. Back\n>> ");
			choosesort=scan.nextInt();scan.nextLine();
			
			switch(choosesort) {
			
			case 1:{
				//nameasc();
				break;
			}
			
			case 2:{
				//namedsc();
				break;
			}
			
			case 3:{
				quan(quantity,0,quantity.size()-1,1);
				break;
			}
			
			case 4:{
				quan(quantity,0,quantity.size()-1,2);
				break;
			}
			}
		}while(choosesort!=0);
		
	}
	
	static void homepage() throws IOException {
		 String fileName = "data/inventory.data";
	        File file = new File(fileName);
	        if (!file.exists()) {
	        	System.out.println("File not found!");
	            System.out.print("Press ENTER to continue...");scan.nextLine();
	        } else {
	        	int jlh = 0;
	        	try(BufferedReader reader= new BufferedReader(new FileReader(fileName))){
	        		String line;
	        		jlh=0;
	        		int tampung;
	        		while((line=reader.readLine())!=null) {
	        			String data[]=line.split("#");
	        			name.add(data[0]);
	        			tampung=Integer.parseInt(data[1]);
	        			quantity.add(tampung);
	        			jlh++;
	        		}
	        	}catch(Exception e) {
	    			e.printStackTrace();
	    		}
	        	
	        	File file1 = new File("data/inventory.data");
	        	try {
	                Scanner scanner = new Scanner(file1);

	                if (!scanner.hasNextLine()) {
	                    System.out.println("There are no inventory!");
	                }	    
	                else {
	        	System.out.println("JACK'S STORAGE");
	        	System.out.println("=====================================================================");
	        	System.out.println("| No.  | Inventory Name                      | Quantity |");
	        	for(int i=0;i<jlh;i++) {
	        		if(i<9)System.out.println("| 00"+(i+1)+"   | "+name.get(i)+"                  |       "+quantity.get(i)+ " |");
	        		else if(i<99)System.out.println("| 0"+(i+1)+"  | "+name.get(i)+"                  |       "+quantity.get(i)+ " |");
	        		else System.out.println("| "+(i+1)+" | "+name.get(i)+"                  |       "+quantity.get(i)+ " |");
	        		
	        	}
	        	System.out.println("=====================================================================");
	        	


	        }

	                scanner.close();
	            } catch (FileNotFoundException e) {
	                e.printStackTrace();
	            }


	        	
	        int choose2;
	        do {
	        	cls();
	        	System.out.println("Main Menu");
	        	System.out.print("1. Insert Data\n2. Update Data\n3. Delete Data\n4. Sort\n0. Exit\n>> ");
	        	choose2=scan.nextInt();scan.nextLine();
	        	
	        	switch(choose2) {
	        	case 1:{
	        		
	        		break;
	        	}
	        	case 2:{
	        		
	        		break;
	        	}
	        	case 3:{
	        		
	        		break;
	        	}
	        	case 4:{
	        		sort();
	        		break;
	        	}
	        	
	        	}
	        		
	        }while(choose2!=0);
		
	}
	}
	
	static void Login() {
		String username="";
		String pass="";	
		
			
			System.out.print("Input username: ");username=scan.nextLine();
			System.out.print("Input password: ");pass=scan.nextLine();
		if(!username.equals("admin") && !pass.equals("NAR23-2")) {
			System.out.println("Invalid username and password!");
			System.out.print("Press ENTER to continue...");scan.nextLine();
		}
		else {
			homepage();
		}

		
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		int choose;
		do {
			cls();
			System.out.println("JACK'S STORAGE");
			System.out.println("Action");
			System.out.print("1. Login\n2. Exit\n>> ");
			choose=scan.nextInt();
			scan.nextLine();
			
			switch(choose) {
			case 1:{
				Login();
				break;
			}			
			}
			
		}while(choose !=2);
	}

}
