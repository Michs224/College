package JAVAILEVELUP;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.io.Writer;
import java.util.ArrayList;
import java.util.Scanner;

public class JAVAILEVELUP {
	static Scanner scan=new Scanner(System.in);
	public JAVAILEVELUP() {
		// TODO Auto-generated constructor stub
	}
	
	static void Order(String name,String pass,int balance) {
		ArrayList<String> Id=new ArrayList<String>();
		ArrayList<String> menuname=new ArrayList<String>();
		ArrayList<Integer> price=new ArrayList<Integer>();
		int jlh=0;
		try (BufferedReader reader = new BufferedReader(new FileReader("userData.txt"))) {
		String line;
		while((line=reader.readLine()) !=null) {
			String data[]=line.split("#");
			Id.add(data[0]);
			menuname.add(data[1]);
			int tampung=Integer.parseInt(data[2]);
			price.add(tampung);
			jlh++;

		}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i=0;i<jlh;i++) {
			for(int j=0;j<jlh-i-1;j++) {
				if(price.get(j)>price.get(j+1)) {
					int temp=price.get(j);
					price.set(j, price.get(j+1));
					price.set(j+1, temp);
					
					String temp2=new String(Id.get(j));
					Id.set(j, Id.get(j+1));
					Id.set(j+1, temp2);
					
					String temp3=new String(menuname.get(j));
					menuname.set(j, menuname.get(j+1));
					menuname.set(j+1, temp2);
				}
			}
		}
		if(jlh==0) {
			System.out.println("Menu doesn't exists!");
			System.out.print("Press enter to continue...");
			scan.nextLine();
			return;
		}
		
		System.out.println("Balance: "+balance);
		System.out.println(" =============================================================");
		System.out.println("| ID               | Name               | Price               |");
		System.out.println(" -------------------------------------------------------------");
		for(int i=0;i<jlh;i++) {
		System.out.printf("| %-15s | %-15s | %-15d |\n",Id.get(i),menuname.get(i),price.get(i));
		}
		System.out.println("\n =============================================================");
		String id="";
		int valid=0,indeks=-1;
		do {
			System.out.print("Input menu ID to order ['0' to go back]: ");
			id=scan.nextLine();
			if(id.equals("0"))return;
			for(int i=0;i<jlh;i++) {
				if(id.equals(Id.get(i))) {
				valid=1;
				indeks=i;
				break;
				}
				
			}
		}while(valid!=1);
		
		int quantity;
		do {
			System.out.println("Input quantity [> 0]: ");
			quantity=scan.nextInt();
			scan.nextLine();
		}while(quantity<=0);
		int totprice=quantity*price.get(indeks);
		System.out.println("Total Price: "+totprice);
		if(balance<totprice)System.out.println("You don't have enough balance !");
		else {
			
			ArrayList<String> names=new ArrayList<String>();
			ArrayList<String> password=new ArrayList<String>();
			ArrayList<Integer> balances=new ArrayList<Integer>();
			
			try (BufferedReader reader = new BufferedReader(new FileReader("userData.txt"))) {
				String line;
				while((line=reader.readLine()) !=null) {
					String data[]=line.split("#");
					names.add(data[0]);
					password.add(data[1]);
					int tampung=Integer.parseInt(data[2]);
					balances.add(tampung);
					if(name.equals(names.get(i))) {
						if(pass.equals(password.get(i))) indeks=i;
						
					}
					jlh++;
					i++;
				}
				
				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				names.remove(indeks);
				password.remove(indeks);
				balances.remove(indeks);
				
				names.add(name);
				password.add(pass);
				balances.add(balance-totprice);
				
				try (BufferedWriter writer = new BufferedWriter(new FileWriter("userData.txt"))) {
				for(int j=0;j<jlh;j++) {
				writer.write(String.format("%s#%s#%d",names.get(j),password.get(j),balances.get(j)));
				writer.newLine();			
				}

				} catch (IOException e) {
					// TODO Auto-generated catch block
					e.printStackTrace();
				}
				
				balance=balance-totprice;
				System.out.println("Order Success !");
			
		}
		System.out.print("Press enter to continue...");
		scan.nextLine();
		
		
	}
	
	static void TopUp(String name,String pass,int balance) {
		ArrayList<String> names=new ArrayList<String>();
		ArrayList<String> password=new ArrayList<String>();
		ArrayList<Integer> balances=new ArrayList<Integer>();
		
		System.out.println("Top Up Balance");
		System.out.println("-------------------");
		int amount;
		do {
			System.out.println("Input top up amoun [> 0]: ");
			amount=scan.nextInt();
			scan.nextLine();
		}while(amount<=0);
		

		int jlh=0,i=0,indeks=-1;
		try (BufferedReader reader = new BufferedReader(new FileReader("userData.txt"))) {
		String line;
		while((line=reader.readLine()) !=null) {
			String data[]=line.split("#");
			names.add(data[0]);
			password.add(data[1]);
			int tampung=Integer.parseInt(data[2]);
			balances.add(tampung);
			if(name.equals(names.get(i))) {
				if(pass.equals(password.get(i))) {
					if(balance==balances.get(i))indeks=i;
				}
			}
			jlh++;
			i++;
		}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		names.remove(indeks);
		password.remove(indeks);
		balances.remove(indeks);
		
		names.add(name);
		password.add(pass);
		balances.add(balance+amount);
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("userData.txt"))) {
		for(int j=0;j<jlh;j++) {
		writer.write(String.format("%s#%s#%d",names.get(j),password.get(j),balances.get(j)));
		writer.newLine();			
		}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		balance=balance+amount;
		System.out.println("Top Up Success !");
		System.out.print("Press enter to continue...");scan.nextLine();
	
	}
	
	static void HomePage(String name, String password,int balance) {
		int choose;
		do {
		System.out.println("Hello "+name+", welcome to mcGonald,");
		System.out.println("----------------------");
		System.out.println("Your balance: "+balance);
		System.out.print("1. Order\n2. Top Up Balance\n3. Back\n>> ");		
		choose=scan.nextInt();
		scan.nextLine();
		switch(choose) {
		case 1:{
			Order(name,password,balance);
			break;
		}
		case 2:{
			TopUp(name,password,balance);
			break;
		}
		}
		}while(choose!=3);

	}
	
	
	static void Register() {
		String name="";
		String pass="";
		int balance;
		System.out.println("Register");
		System.out.println("---------");
		
		do {
			System.out.println("Input name [> 3 char & unique]: ");
			name=scan.nextLine();
		}while(name.length()<=3);
		do {
			System.out.println("Input password [> 5 char]: ");
			pass=scan.nextLine();
		}while(pass.length()<=5);
		do {
			System.out.println("Input initial [> 0]: ");
			balance=scan.nextInt();
			scan.nextLine();
		}while(balance<=0);
		

		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("userData.txt",true))) {
		writer.write(String.format("%s#%s#%d",name,pass,balance));
		writer.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		System.out.println("Register Success !");
		System.out.print("Press Enter to continue...");
		scan.nextLine();
		HomePage(name,pass,balance);
	}
	
	
	static void Login() {
		ArrayList<String> name=new ArrayList<String>();
		ArrayList<String> pass=new ArrayList<String>();
		ArrayList<Integer> balances=new ArrayList<Integer>();

		int jlh=0;
		try (BufferedReader reader = new BufferedReader(new FileReader("userData.txt"))) {
		String line;
		while((line=reader.readLine()) !=null) {
			String data[]=line.split("#");
			name.add(data[0]);
			pass.add(data[1]);
			int tampung=Integer.parseInt(data[2]);
			balances.add(tampung);
			jlh++;
		}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		String names="";
		String password="";
		System.out.println("Login");
		System.out.println("-------");
		int valid=0,i;
		do {
			
			System.out.print("Enter name [case sensitive]: ");
			names=scan.nextLine();
			System.out.print("Enter password [case sensitive]: ");
			password=scan.nextLine();
			
			for(i=0;i<jlh;i++) {
				if(names.equals(name.get(i))) {
					if(password.equals(pass.get(i))) {
						valid=1;
						break;
					}
				}
			}
			if(valid!=1) {
				System.out.println("Wrong Credential !");
			}
			else {
				System.out.println("Login Success !");
			}
			System.out.print("Press Enter to continue...");
			scan.nextLine();
		}while(valid!=1);
	
		HomePage(names,password,balances.get(i));
		
	}
	
	static void Customer() {
		int choose1;
		do {
			System.out.println("Welcome to mcGonald,");
			System.out.println("-------------");
			System.out.print("1. Login\n2. Register\n3. Back\n>> ");
			choose1=scan.nextInt();
			scan.nextLine();
			switch(choose1) {
			case 1:{
				Login();
				break;
			}
			case 2:{
				Register();
				break;
			}
			}
		}while(choose1!=3);
		
	}
	
	static void Cashier() {
		int choosee2;
		System.out.println("Welcome to mcGonald");
		System.out.println("-------------------");
		System.out.print("1. View All Menu\n2. Add New Menu\n3. Remove Menu\n4. Update Menu\n5. Back\n>> ");
		choosee2=scan.nextInt();
		scan.nextLine();
	}

	public static void main(String[] args) {
	int choose;
	do {
		System.out.println("Welcome to mcGonald,");
		System.out.println("-------------");
		System.out.print("1. Customer\n2. Cashier\n3. Exit\n>> ");
		choose=scan.nextInt();
		scan.nextLine();
		switch(choose) {
		case 1:{
			Customer();
			break;
		}
		case 2:{
			Cashier();
			break;
		}
		}
	}while(choose!=3);
	
	System.out.println("Goodbye !");
	System.out.println("Wonderful things can be achieved when there is a teamwork, hardwork, and perseverance");
	System.out.println("- Bluejack 22-2");
	}

}
