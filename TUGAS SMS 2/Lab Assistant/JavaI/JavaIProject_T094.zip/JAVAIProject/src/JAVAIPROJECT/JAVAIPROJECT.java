package JAVAIPROJECT;

import java.io.BufferedReader;
import java.io.BufferedWriter;
import java.io.FileReader;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.Random;
import java.util.Scanner;

public class JAVAIPROJECT {
	static Scanner scan= new Scanner(System.in);
	static Random rand=new Random();
	
	static ArrayList<String> names=new ArrayList<String>();
	static ArrayList<String> namescore=new ArrayList<String>();
	static ArrayList<Integer> orderscore=new ArrayList<Integer>();
	static ArrayList<Integer> moneyscore=new ArrayList<Integer>();
	
	public JAVAIPROJECT() {
		// TODO Auto-generated constructor stub
	}
	

		    static void cls() {
		        System.out.print("\033[H\033[2J");  
		        System.out.flush();  
		    }
		    
//	static void toylist() {
//		
//	}
	 
	static String randomtoy() {
		    	int x=rand.nextInt(6)+1;
		    	if(x==1)return "Teddy Bear";
		    	else if(x==2) return "Toy Car";
		    	else if(x==3) return "Toy Plane";
		    	else if(x==4) return "RC Car";
		    	else if(x==5) return "Train Set";
		    	else if(x==6) return "Transform Robot";
		    	return null;
		    	
		    }
	
	static void SaveData(String name,int money,int difficulty,int ordersdone,int workers,int toylist,String currorder,int leveluptarget) {
		
		ArrayList<String> usernames=new ArrayList<String>();
		ArrayList<Integer> moneys=new ArrayList<Integer>();
		ArrayList<Integer> diffi=new ArrayList<Integer>();
		ArrayList<Integer> orderdones=new ArrayList<Integer>();
		ArrayList<Integer> totworkers=new ArrayList<Integer>();
		ArrayList<Integer> toylists=new ArrayList<Integer>();
		ArrayList<String> currentorder=new ArrayList<String>();
		ArrayList<Integer> levuptarget=new ArrayList<Integer>();
		int jlh=0;
		
		ArrayList<String> namesaves=new ArrayList<String>();
		
		try (BufferedReader reader = new BufferedReader (new FileReader("[playername].txt"))) {
		String line;

		while((line=reader.readLine()) != null) {
			String datas[]=line.split(",");
			usernames.add(datas[0]);
			int t1=Integer.parseInt(datas[1]);
			moneys.add(t1);
			int t2=Integer.parseInt(datas[2]);
			diffi.add(t2);
			int t3=Integer.parseInt(datas[3]);
			orderdones.add(t3);
			int t4=Integer.parseInt(datas[4]);
			totworkers.add(t4);
			int t5=Integer.parseInt(datas[5]);
			toylists.add(t5);
			currentorder.add(datas[6]);
			int t6=Integer.parseInt(datas[7]);
			levuptarget.add(t6);
			jlh++;

		}
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		
		int jlh2=0;
		try (BufferedReader reader = new BufferedReader (new FileReader("save.txt"))) {
		String line;
		
		while((line=reader.readLine()) != null) {
			namesaves.add(line);
			jlh2++;
		}
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		int l=-1;
		for(int i=0;i<jlh2;i++) {
			if(name.equals(namesaves.get(i))) {
				l=i;
				break;
			}
		}
		
		int k=-1;
		for(int i=0;i<jlh;i++) {
			if(name.equals(usernames.get(i))) {
				k=i;
				break;
			}
		}
		usernames.remove(k);
		moneys.remove(k);
		diffi.remove(k);
		orderdones.remove(k);
		totworkers.remove(k);
		toylists.remove(k);
		currentorder.remove(k);
		levuptarget.remove(k);
		
		namesaves.remove(l);
		
		
		usernames.add(name);
		moneys.add(money);
		diffi.add(difficulty);
		orderdones.add(ordersdone);
		totworkers.add(workers);
		toylists.add(toylist);
		currentorder.add(currorder);
		levuptarget.add(leveluptarget);
		
		namesaves.add(name);
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("[playername].txt"))) {
			for(int i=0;i<jlh-1;i++) {
			writer.write(String.format("%s,%d,%d,%d,%d,%d,%d,%d",usernames.get(i),moneys.get(i),diffi.get(i),orderdones.get(i),totworkers.get(i),toylists.get(i),currentorder.get(i),levuptarget.get(i)));
			writer.newLine();				
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("[playername].txt"))) {
			for(int i=0;i<jlh2-1;i++) {
			writer.write(String.format("%s",namesaves.get(i)));
			writer.newLine();				
			}

		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	}
	


	static void GameMenu(String name,int money,int difficulty,int ordersdone,int workers,int toylist,String currorder,int leveluptarget) {
		
		int quantity,countdown,level;
		String toy="";
		do {
		cls();
		toy=randomtoy();
		currorder=new String(toy);
//		currorder=(String) "".concat(toy);
		level=(rand.nextInt(5)+1)%5;
		//int quantity=(rand.nextInt(n-1))+(rand.nextInt(55+n-1))+100;//Pattern di soal yang diberikan seperti ini naun, jika difficultynya 1 mka tidak bisa memenuhi karena akan mendapat hasil 0, dimana 0 sendiri tidak bisa dijadikan rentang random number, karena rentang random number harus lebih besar dari 0
		quantity=(rand.nextInt(difficulty))+(rand.nextInt((55+difficulty)-1))+100;
		countdown=quantity/workers/(rand.nextInt(5)+1);
		System.out.println("Toy VacTory Manager");
		System.out.println("========================================");
		System.out.println("Current Order");
		System.out.println("========================================");
		System.out.println("Toy         : "+toy);
		System.out.println("Level       : "+level);
		System.out.println("Quantitiy   : "+quantity);
		System.out.println("Time        : "+countdown);
		System.out.println("Difficulty  : "+difficulty);
		System.out.println("Money       : "+money);
		System.out.println("Orders Done : "+ordersdone);
		System.out.println("========================================\n\n");
		int choosegame;
		String check="";
		do {
//			cls();
			System.out.print("1. Show Toy List\n2. Produce Toys\n3. Manage Workers\n4. Save and Exit Game\n5. End Game\n>> ");
			choosegame=scan.nextInt();scan.nextLine();
			switch(choosegame) {
			case 1:{
				//ShowToyList();
				break;
			}
			case 2:{
				//ProduceToys();
				break;
			}
			case 3:{
				//ManageWorkers();
				break;
			}
			case 4:{
				SaveData(name,money,difficulty,ordersdone,workers,toylist,currorder,leveluptarget);
				break;
			}
			case 5:{
				do {
				System.out.print("Are you sure you want to end game (You cannot load this game after this!) ? [Y/N]: ");
				check=scan.nextLine();					
				}while(!check.equals("Y") || !check.equals("N"));

				break;
			}
			}
		}while(choosegame!=4 && (toylist<quantity || countdown==0) || (choosegame!=5 && !check.equals("Y")));			
		}while(toylist>=quantity || countdown!=0);
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("[playername].txt",true))) {
			writer.write(String.format("%s,%d,%d",name,ordersdone,money));
			writer.newLine();				
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
	}
	
	static void HighScore() {
		ArrayList<String> namescore = new ArrayList<String>();
		ArrayList<Integer> orderscore = new ArrayList<Integer>();
		ArrayList<Integer> moneyscore = new ArrayList<Integer>();
		int jlh=0;
		try (BufferedReader reader = new BufferedReader(new FileReader("hiscore.txt"))) {
		String line;
		while((line=reader.readLine())!=null) {
			String data[]=line.split(",");
			namescore.add(data[0]);
			int t1=Integer.parseInt(data[1]);
			orderscore.add(t1);
			int t2=Integer.parseInt(data[2]);
			moneyscore.add(t2);
			jlh++;
		}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		for(int i=0;i<jlh-1;i++) {
			for(int j=0;j<jlh-i-1;j++) {
				if(orderscore.get(j) < orderscore.get(j+1)) {
					
					String temp1 = new String(namescore.get(j));
					namescore.set(j, namescore.get(j+1));
					namescore.set(j+1, temp1);
					
					int temp2=orderscore.get(j);
					orderscore.set(j, orderscore.get(j+1));
					orderscore.set(j+1, temp2);
					
					int temp3=moneyscore.get(j);
					moneyscore.set(j, moneyscore.get(j+1));
					moneyscore.set(j+1, temp3);
				}
			}
		}
		
		if(jlh==0) {
			System.out.println("No high score data\n");
		}
		else {
			System.out.println("===================================================");
			System.out.println("| Name                      | Orders | Money      |");
			System.out.println("===================================================");
			for(int i=0;i<jlh;i++){
			System.out.printf("| %-25s | %-6d | %-10d |\n",namescore.get(i),orderscore.get(i),moneyscore.get(i));				
			}
			System.out.println("===================================================\n");

		}
		System.out.print("Press Enter to Continue...");scan.nextLine();scan.nextLine();
		
		
	}
	
	static void LoadGame() {
//		cls();
		int money=0,difficulty=1,ordersdone=0,workers=5,toylist=0,leveluptarget=0;
		String currorder="";
		String name="";
		ArrayList<String> namesload=new ArrayList<String>();
//		String name="";
		System.out.println("Toy VacTory Manager");
		System.out.println("======================");
		System.out.println("Save files");
		System.out.println("======================");
		int i = 0;


		try (BufferedReader reader = new BufferedReader (new FileReader("save.txt"))) {
		String line;
		i=0;
		while((line=reader.readLine()) != null) {
			namesload.add(line);
			System.out.println((i+1)+". "+namesload.get(i));
			i++;
		}
		
		} catch (IOException e) {
			e.printStackTrace();
		}
		if(i==0) {
			System.out.println("No save files yet\n");
			System.out.print("Press Enter to Continue...");scan.nextLine();scan.nextLine();
			return;
		}
		int x;
		do {
			System.out.print("Please select a save file to load [0 to go back]: ");
			x=scan.nextInt();scan.nextLine();
			if(x==0)return;
			if(x<1 || x>i+1) {
				System.out.println("Input must be between 1 and the number of saved games");
			}
		}while(x<1 || x>i+1);
		
		ArrayList<String> usernames=new ArrayList<String>();
		ArrayList<Integer> moneys=new ArrayList<Integer>();
		ArrayList<Integer> diffi=new ArrayList<Integer>();
		ArrayList<Integer> orderdones=new ArrayList<Integer>();
		ArrayList<Integer> totworkers=new ArrayList<Integer>();
		ArrayList<Integer> toylists=new ArrayList<Integer>();
		ArrayList<String> currentorder=new ArrayList<String>();
		ArrayList<Integer> levuptarget=new ArrayList<Integer>();
		
		
		try (BufferedReader reader = new BufferedReader (new FileReader("[playername].txt"))) {
			String line;

			while((line=reader.readLine()) != null) {
				String datas[]=line.split(",");
				usernames.add(datas[0]);
				int t1=Integer.parseInt(datas[1]);
				moneys.add(t1);
				int t2=Integer.parseInt(datas[2]);
				diffi.add(t2);
				int t3=Integer.parseInt(datas[3]);
				orderdones.add(t3);
				int t4=Integer.parseInt(datas[4]);
				totworkers.add(t4);
				int t5=Integer.parseInt(datas[5]);
				toylists.add(t5);
				currentorder.add(datas[6]);
				int t6=Integer.parseInt(datas[7]);
				levuptarget.add(t6);

			}
			
			} catch (IOException e) {
				e.printStackTrace();
			}
		name=usernames.get(x-1);
		money=moneys.get(x-1);
		difficulty=diffi.get(x-1);
		ordersdone=orderdones.get(x-1);
		workers=totworkers.get(x-1);
		toylist=toylists.get(x-1);
		currorder=currentorder.get(x-1);
		leveluptarget=levuptarget.get(x-1);
		
		GameMenu(name,money,difficulty,ordersdone,workers,toylist,currorder,leveluptarget);
	}
	
	
	static void NewGame() {
		int money=0,difficulty=1,ordersdone=0,workers=5,toylist=0,leveluptarget=0;
		String currorder="";
		
		
		String name="";
		int n,check,valid;
		
		try (BufferedReader reader = new BufferedReader (new FileReader("save.txt"))) {
		String line;
		while((line=reader.readLine()) != null) {
			names.add(line);
		}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try (BufferedReader reader = new BufferedReader (new FileReader("hiscore.txt"))) {
		String line;
		while((line=reader.readLine()) != null) {
			String data[]=line.split(",");
			namescore.add(data[0]);
			int ord=Integer.parseInt(data[1]);
			orderscore.add(ord);
			int mon=Integer.parseInt(data[2]);
			moneyscore.add(mon);
		}
		
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		do {
		valid=0;
		check=0;
		System.out.print("Input player's name [0 to go back]: ");scan.nextLine();
		name=scan.nextLine();
		if(name.equals("0"))return;
		n=name.length();
		if(n<3 || n>20) System.out.println("Name must be between 3 to 20 characters!\n");
		else valid++;
		for(int i=0;i<names.size();i++) {
			if(name.equals(names.get(i)))check=1;
		}
		for(int i=0;i<namescore.size();i++) {
			if(name.equals(namescore.get(i)))check=1;
		}
		if(check==1) {
			System.out.println("User with that name already exists!");
		}
		else valid++;
		
		}while(valid!=2);
		
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("save.txt",true))) {
			writer.write(String.format("%s",name));
			writer.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		
		try (BufferedWriter writer = new BufferedWriter(new FileWriter("[playername].txt",true))) {
			writer.write(String.format("%s,%d,%d,%d,%d,%d,%d,%d",name,money,difficulty,ordersdone,workers,toylist,currorder,leveluptarget));
			writer.newLine();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
	
		GameMenu(name,money,difficulty,ordersdone,workers,toylist,currorder,leveluptarget);

	}

	public static void main(String[] args) {
		
		
		int choose;
		do {
			cls();
			System.out.println("Toy VacTory Manager");
			System.out.print("1. New Game\n2. Load Game\n3. High Score\n4. Exit\n>> ");
			choose =scan.nextInt();
			
			switch(choose) {
			case 1:{
				NewGame();
				break;
			}
			
			case 2:{
				LoadGame();
				break;
			}
			
			case 3:{
				HighScore();
				break;
			}
			}
			
		}while(choose!=4);
		
		System.out.println("                           Thank you for playing the game.");
		System.out.println("                                - Bluejackets 22-1 -");
		System.out.println("          Alongside courage and perseverance, we shape and define our future.");

	}

}
