/**
 * 
 */
/**
 * @author user
 *
 */
module JAVAIProject {
}