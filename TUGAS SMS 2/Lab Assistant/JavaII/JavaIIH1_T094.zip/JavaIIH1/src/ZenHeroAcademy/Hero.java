package ZenHeroAcademy;

import java.util.Vector;

public class Hero {
	public String name;
	public String gender;
	public String type;
	public int age;
	public Vector<Melee> melee=new Vector<Melee>();
	public Vector<Ranged> range=new Vector<Ranged>();
	
	public Hero(String name, String gender,int age, String type) {
		this.name=name;
		this.gender=gender;
		this.age=age;
		this.type=type;
	}
	public void setMelee(Vector<Melee> melee) {
		this.melee=melee;
	}
//	public Melee getMelee(Melee melee) {
//		
//	}
	public void setRanged(Ranged range) {
		
	}
	public void getRanged(Ranged range) {
		
	}


	
}
