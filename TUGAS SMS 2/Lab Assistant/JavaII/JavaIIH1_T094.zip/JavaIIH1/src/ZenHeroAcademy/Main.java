package ZenHeroAcademy;

import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main {

	Scanner scan= new Scanner(System.in);
	
	Vector<String> names=new Vector<String>();
	Vector<Integer> ages=new Vector<Integer>();
	Vector<String> genders=new Vector<String>();
	Vector<String> types=new Vector<String>();
	
	Vector<Hero> heroes=new Vector<Hero>();
	Vector<Melee> melee=new Vector<Melee>();
	Vector<Ranged> range=new Vector<Ranged>();
	
	public void add() {
		String name;
		String gender;
		int age;
		String type;
		
		do {
		System.out.print("Enter name [Name Length >= 9]: ");
		name=scan.nextLine();
		}while(name.length()<9);
		
		do {
		System.out.print("Enter age [Age >= 21]: ");
		age=scan.nextInt();scan.nextLine();
		}while(age<21);
		
		do {
		System.out.print("Enter gender [Male | Female] (Case Sensitive): ");
		gender=scan.nextLine();
		}while(!gender.equals("Male") || !gender.equals("Female"));
		
		do {
		System.out.print("Enter type [Melee | Ranged] (Case Sensitive): ");
		type=scan.nextLine();
		}while(!type.equals("Melee") || !type.equals("Ranged"));
		

		
		int swordlength;
		int shield;
		String id;
		Random rand=new Random();
		if(type.equals("Melee")) {
			do {
				System.out.print("Enter sword length [must be greater than or equal to 232]: ");
				swordlength=scan.nextInt();
				scan.nextLine();
			}while(swordlength<232);
			
			do {
				System.out.print("Enter shield weight [must be greater than 0]: ");
				shield=scan.nextInt();
				scan.nextLine();
			}while(shield<0);
			
			id=new String("ML");
			
			for(int i=0;i<3;i++) {
				String x=Integer.toString(rand.nextInt(10));	
				id.concat(x);
			}
			Melee melee=new Melee(swordlength,shield,id);
			
			
		}
		else if(type.equals("Ranged")) {
			
		}
		
//		names.add(name);
//		genders.add(gender);
//		ages.add(age);
//		types.add(type);
		
		Hero hero=new Hero(name,gender,age,type);
		hero.setMelee(melee);
		//hero.setRanged(range);
		
//		hero.name=name;
//		hero.gender=gender;
//		hero.age=age;
//		hero.type=type;
		
//		heroes.add(new Hero(name,gender,age,type));//bisa gini juga
		
		heroes.add(hero);
	}
	
	public Main() {
		System.out.println("ZEN HERO ACADEMY");
		System.out.print("1. Add hero\n2. View hero\n3. Remove hero\n4. Update hero\n5. Exit\n>> ");
		int choose;
		do {
		choose=scan.nextInt();scan.nextLine();
		switch(choose) {
		
		case 1:{
			add();
			break;
		}
		case 2:{
			
			break;
		}
		case 3:{
			
			break;
		}
		case 4:{
			
			break;
		}

		}			
		}while(choose!=5);

		
		
	}

	public static void main(String[] args) {
		
		new Main();
	}

}
