package ZenHeroAcademy;

public class Melee {
	public String id;
	public int shield;
	public int swordlength;
	
	
	public Melee(int swordlength,int shield,String id) {
	this.swordlength=swordlength;
	this.shield=shield;
	this.id=id;
	}



}
