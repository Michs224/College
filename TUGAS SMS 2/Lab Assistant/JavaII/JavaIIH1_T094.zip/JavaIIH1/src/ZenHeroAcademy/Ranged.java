package ZenHeroAcademy;

public class Ranged {
	public String bowq;
	public int arrowq;
	public String id;
	
	public Ranged() {
		
	}



}
