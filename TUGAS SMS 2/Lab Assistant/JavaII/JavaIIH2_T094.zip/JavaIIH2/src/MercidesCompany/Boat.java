package MercidesCompany;

public class Boat extends Vehicle{
	String sailtype;
	String id;
	//Integer horsepower,price; //value dari enginetype tidak diberitahu
	public Boat(String vehicletype, String vehiclename, String enginename, String enginemanu, String enginetype,
			String color, String sailtype,String id) {
		super(vehicletype, vehiclename, enginename, enginemanu, enginetype, color);
		this.sailtype = sailtype;
		this.id=id;
	}

		// TODO Auto-generated constructor stub



}
