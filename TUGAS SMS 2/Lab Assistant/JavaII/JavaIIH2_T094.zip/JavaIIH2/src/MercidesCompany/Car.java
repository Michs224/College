package MercidesCompany;

public class Car extends Vehicle{
	String cartype,id;
	//Integer horsepower,price; //value dari enginetype tidak diberitahu
	public Car(String vehicletype, String vehiclename, String enginename, String enginemanu, String enginetype,
			String color, String cartype,String id) {
		super(vehicletype, vehiclename, enginename, enginemanu, enginetype, color);
		this.cartype = cartype;
		this.id=id;
	}
	
	

}
