package MercidesCompany;

import java.util.List;
import java.util.Random;
import java.util.Scanner;
import java.util.Vector;

public class Main {
Scanner scan= new Scanner(System.in);

Vector<Vehicle> vehicles= new Vector<>();
//List<Vehicle> bb=new List<Vehicle>();

	Vehicle vehicle;
	Car car;
	Boat boat;
	Plane plane;
	public void View() {
		
		
		
	}
	
	public void Create() {
		String vehicletype;
		String vehiclename;
		String enginename;
		String enginemanu;
		String enginetype;
		String color;
		
		do {
			
			System.out.print("Input Vehicle (Boat / Car / Plane) [Case sensitive]: ");
			vehicletype=scan.nextLine();
			
		}while(!vehicletype.equals("Boat") || !vehicletype.equals("Car") || !vehicletype.equals("Plane"));
		
		do {
			
			System.out.print("Input Vehicle name (6 - 14 chars) : ");
			vehiclename=scan.nextLine();
			
		}while(vehiclename.length()<8 || vehiclename.length()>14);
		
		do {
			System.out.print("Input Engine's name (8 - 16 chars) : ");
			enginename=scan.nextLine();
			
		}while(enginename.length()<8 || enginename.length()>16);
		
		do {
			System.out.print("Input Engine's Manufacturer (Yamaha / Suzuki / Honda) [Case sensitive] : ");
			enginemanu=scan.nextLine();
			
		}while(!enginemanu.equals("Yamaha") || !enginemanu.equals("Suzuki") || !enginemanu.equals("Honda"));
		
		do {
			System.out.print("Input Engine's type (Electric / Diesel / Turbine) [Case sensitive] : ");
			enginetype=scan.nextLine();
			
		}while(!enginetype.equals("Electric") || !enginetype.equals("Diesel") || !enginetype.equals("Turbine"));
		
		do {
			System.out.print("Input Vehicle color (Black / White / Grey) [Case sensitive] : ");
			color=scan.nextLine();
			
		}while(!color.equals("Black") || !color.equals("White") || !color.equals("Grey"));
		
//		vehicle= new Vehicle(vehicletype,vehiclename,enginename,enginemanu,enginetype,color);
		String id;
		Random rand=new Random();
		if(vehicletype.equals("Car")) {
			String cartype;
			do {
				
				System.out.print("Input car's type (Sedan,Truck, SUV) [Case sensitive] : ");
				cartype=scan.nextLine();
			}while(!cartype.equals("Sedan") || !cartype.equals("Truck") || !cartype.equals("SUV"));
			
			id=new String("VH");
			
			for(int i=0;i<3;i++) {
				String x=Integer.toString(rand.nextInt(10));
				id.concat(x);
			}
			
			car=new Car(vehicletype,vehiclename,enginename,enginemanu,enginetype,color,cartype,id);
			vehicle=car;
		}
		else if(vehicletype.equals("Boat")) {
			String sailboat;
			do {
				
				System.out.print("Input Boat's sail (Triangle / Spinnaker / Square) [Case sensitive] : ");
				sailboat=scan.nextLine();
			}while(!sailboat.equals("Triangle") || !sailboat.equals("Spinnaker") || !sailboat.equals("Square"));
			
			id=new String("VH");
			
			for(int i=0;i<3;i++) {
				String x=Integer.toString(rand.nextInt(10));
				id.concat(x);
			}
			
			boat=new Boat(vehicletype,vehiclename,enginename,enginemanu,enginetype,color,sailboat,id);
			vehicle=boat;
		}
		else{
			String wingplane;
			do {
				System.out.print("Input Plane's wing type (Straight / Delta / High) [Case sensitive] : ");
				wingplane=scan.nextLine();
			}while(!wingplane.equals("Straight") || !wingplane.equals("Delta") || !wingplane.equals("High"));
			
			id=new String("VH");
			
			for(int i=0;i<3;i++) {
				String x=Integer.toString(rand.nextInt(10));
				id.concat(x);
			}
			
			plane=new Plane(vehicletype,vehiclename,enginename,enginemanu,enginetype,color,wingplane,id);
			vehicle=plane;
		}
		
		vehicles.add(vehicle);
		
		
	}

	public Main() {
		
		int choose;
		
		do {
		System.out.println("Welcome to Merci Company");
		System.out.print("1. View vehicle\n2. Create a vehicle\n3. Delete vehicle\n4. Exit\n4. Exit\n>> ");			
		choose=scan.nextInt();scan.nextLine();
		switch(choose) {
		case 1:{
			View();
		}
		case 2:{
			Create();
		}
		case 3:{
			
		}
		
		}
		}while(choose!=4);

		
	
	}

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		new Main();
	}

}
