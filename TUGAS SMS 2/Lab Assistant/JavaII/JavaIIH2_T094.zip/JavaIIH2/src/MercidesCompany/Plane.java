package MercidesCompany;

public class Plane extends Vehicle {
	String wingtype,id;
	//Integer horsepower,price; //value dari enginetype tidak diberitahu
	public Plane(String vehicletype, String vehiclename, String enginename, String enginemanu, String enginetype,
			String color, String wingtype,String id) {
		super(vehicletype, vehiclename, enginename, enginemanu, enginetype, color);
		this.wingtype = wingtype;
		this.id=id;
	}
	


}
