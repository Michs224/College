package MercidesCompany;

public class Vehicle {
	String vehicletype;
	String vehiclename;
	String enginename;
	String enginemanu;
	String enginetype;
	String color;
	
	public Vehicle(String vehicletype, String vehiclename,String enginename, String enginemanu, String enginetype, String color) {
		super();
		this.vehicletype = vehicletype;
		this.vehiclename=vehiclename;
		this.enginename = enginename;
		this.enginemanu = enginemanu;
		this.enginetype = enginetype;
		this.color = color;
	}

	public String getVehicletype() {
		return vehicletype;
	}

	public void setVehicletype(String vehicletype) {
		this.vehicletype = vehicletype;
	}

	public String getVehiclename() {
		return vehiclename;
	}

	public void setVehiclename(String vehiclename) {
		this.vehiclename = vehiclename;
	}

	public String getEnginename() {
		return enginename;
	}

	public void setEnginename(String enginename) {
		this.enginename = enginename;
	}

	public String getEnginemanu() {
		return enginemanu;
	}

	public void setEnginemanu(String enginemanu) {
		this.enginemanu = enginemanu;
	}

	public String getEnginetype() {
		return enginetype;
	}

	public void setEnginetype(String enginetype) {
		this.enginetype = enginetype;
	}

	public String getColor() {
		return color;
	}

	public void setColor(String color) {
		this.color = color;
	}


	


}
