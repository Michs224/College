package StaffManager;

public class Company {
	String name;
	Integer payroll,sales;

	public Company(String name,Integer payroll, Integer sales) {
		super();
		this.name=name;
		this.payroll = payroll;
		this.sales = sales;
	}


	public String getName() {
		return name;
	}


	public void setName(String name) {
		this.name = name;
	}


	public Integer getPayroll() {
		return payroll;
	}


	public void setPayroll(Integer payroll) {
		this.payroll = payroll;
	}




	public Integer getSales() {
		return sales;
	}




	public void setSales(Integer sales) {
		this.sales = sales;
	}



}
