package StaffManager;

public class Department extends Company{

	public Department(String name, Integer payroll, Integer sales) {
		super(name, payroll, sales);
	}

}
