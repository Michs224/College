package StaffManager;

public class Employee{
	String id,name;
	Integer salary,payroll;
	
	public Employee(String name, Integer payroll, String id, Integer salary) {
		this.name=name;
		this.id = id;
		this.salary = salary;
		this.payroll=payroll;
	}

}
