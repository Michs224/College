package StaffManager;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	List<Company> companies= new ArrayList<Company>();
	Company company= new Company("BlueJack Company",0,0);
	Scanner scan= new Scanner(System.in);
	
	Utility utility= new Utility();
	public void ViewCom() {
		companies.add(company);
		System.out.println(company.getName());
		System.out.println("====================================");
		System.out.println("Total Payroll: "+company.getPayroll());
		System.out.println("Total Sales: "+company.getSales());
		System.out.println("====================================");
		
		utility.PressEnterToContinue();
		utility.Cls();
		
		
	}
	
	public boolean isUnique(String name) {
		
		for (Company company : companies) {
			Department temp= (Department) company;
			if(temp.getName().equals(name)) {
				return false;
			}
		}
		return true;
	}
	
	public void DeleteDepartment() {
		String name;
		int check;
		do {
			System.out.println("Input department name: ");
			name=scan.nextLine();
			check=0;
			for (Company company : companies) {
				Department temp= (Department) company;
				if(!temp.getName().equals(name)) {
					//
					check=1;
				}
			}
		
		}while(check==0);
		
		
		
		
	}
	
	public void AddDepartment() {
		String name;
		do {
			System.out.println("Input department name: ");
			name=scan.nextLine();
			
			if(!isUnique(name)) {
				System.out.println("Please input a valid department name!");
			}
		}while(!isUnique(name));
		
		companies.add(new Department(name,0,0));
		
	}
	
	public void ManageDep() {
		int choose;
		
		int isempty=0;;
		
		for (Company company : companies) {
			int i=1;
			Department depart= (Department) company;
			if(company!=null) {
				System.out.println(i +" "+ depart.getName() +" (total sales : "+depart.getPayroll()+", payroll: "+depart.getSales()+")");
				isempty=1;
			}
			i++;
		}
		if(isempty==0) {
			System.out.println("There is no Department");
			System.out.println("===========================================");
			System.out.println("Add Department!");
			utility.PressEnterToContinue();
			utility.Cls();
		}
		else if(isempty==1) {
			int choose1;
			do {
			for (Company company : companies) {
				int i=1;
				Department depart= (Department) company;
				System.out.println(i +" "+ depart.getName() +" (total sales : "+depart.getPayroll()+", payroll: "+depart.getSales()+")");
				i++;
			}
			System.out.println("===========================================");
			System.out.print("1. Add Department\n2. Delete Department\n3. Back\n>> ");
			
			choose1=scan.nextInt();scan.nextLine();
				
			switch(choose1) {
			case 1:{
				AddDepartment();
				break;
			}
			case 2:{
				DeleteDepartment();
				break;
			}
			
			
			}
			
			}while(choose1!=3);
		}
		
		
	}
	
	public void ManageEmp() {
		
		
	}
	
	
	public Main() {
		int choose;
		
		do{
			System.out.println("Staff Management - Bluejack Company");
			System.out.println("===================================");
			System.out.print("1. View Company\n2. Manage Department\n3. Manage Employee\n4. Exit\n>> ");
			choose=scan.nextInt();scan.nextLine();
			
			switch(choose) {
			case 1:{
				ViewCom();
				break;
			}
			case 2:{
				ManageDep();
				break;
			}
			case 3:{
				ManageEmp();
				break;
			}
			}
		}while(choose!=4);
		
		
	}

	public static void main(String[] args) {
		new Main();
	}

}

