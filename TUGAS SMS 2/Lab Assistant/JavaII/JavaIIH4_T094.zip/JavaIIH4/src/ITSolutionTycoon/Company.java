package ITSolutionTycoon;

public class Company {
	Float cash;
	String building;
	String companyname;
	public Company(String companyname,Float cash, String building) {
		super();
		this.companyname=companyname;
		this.cash = cash;
		this.building = building;
	}
	
	

}
