package ITSolutionTycoon;

public class Employee implements Company{
		String employeename,specialization,status;
		Integer level;
		Float wage;
		public Employee(String employeename, String specialization, String status, Integer level, Float wage) {
			super();
			this.employeename = employeename;
			this.specialization = specialization;
			this.status = status;
			this.level = level;
			this.wage = wage;
		}
		public String getEmployeename() {
			return employeename;
		}
		public void setEmployeename(String employeename) {
			this.employeename = employeename;
		}
		public String getSpecialization() {
			return specialization;
		}
		public void setSpecialization(String specialization) {
			this.specialization = specialization;
		}
		public String getStatus() {
			return status;
		}
		public void setStatus(String status) {
			this.status = status;
		}
		public Integer getLevel() {
			return level;
		}
		public void setLevel(Integer level) {
			this.level = level;
		}
		public Float getWage() {
			return wage;
		}
		public void setWage(Float wage) {
			this.wage = wage;
		}


}
