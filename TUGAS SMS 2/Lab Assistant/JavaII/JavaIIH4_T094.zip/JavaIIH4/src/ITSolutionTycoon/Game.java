package ITSolutionTycoon;

public class Game {

	public Game() {
		// TODO Auto-generated constructor stub
	}

}
