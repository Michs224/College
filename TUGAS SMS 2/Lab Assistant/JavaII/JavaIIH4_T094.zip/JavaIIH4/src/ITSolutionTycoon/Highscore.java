package ITSolutionTycoon;

public class Highscore {

	public Highscore() {
		// TODO Auto-generated constructor stub
	}

}
