package ITSolutionTycoon;

import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	Scanner scan = new Scanner(System.in);
	Utility utility= new Utility();
	List<Company> companies= new ArrayList<Company>();
	Company companyy;
	
	
	public void MainMenu(String namecompany,Float cash,String building) {
		
	}
	
	
	public void PlayGame() {
		Float cash;
		String building;
		int starting;
		do {
			System.out.print("Input your starting cash [100-500]: ");
			cash=scan.nextFloat();
			scan.nextLine();
			
		}while(cash<100.00 || cash>500.00);
		
		do {
			System.out.print("Input your starting employee [1-3]: ");
			starting=scan.nextInt();scan.nextLine();
		}while(starting <1 || starting>3);
		
		Company newcompany = null;
		int check=0;
		for (Company company : companies) {
			if(company instanceof Employee) {
				if(company!=null)check=1;
			}
		}
		if(check==1) {
			System.out.println("Emloyee Empty");
			utility.entertocontinue();
			utility.cls();
			return;
		}
		else {
			System.out.println("=====================================================================================================");	
			System.out.println("|No|                             	Employee Name |    Level |     Wage | Specialization |   Status |");
			for(int i=0;i<starting;i++) {
				Employee temp= (Employee) newcompany;
				System.out.printf("|%2d| %20s | %7d | %10d | %14s | %10s |\n",temp.getEmployeename(),temp.getLevel(),temp.getWage(),temp.getSpecialization(),temp.getStatus());
			}
			System.out.println("=====================================================================================================");
			String yesno=null;
			do {
				System.out.print("Are you sure to continue [Y/N]: ");
				yesno=scan.nextLine();
			}while(!yesno.equalsIgnoreCase("Y") && !yesno.equalsIgnoreCase("N"));
		
			do {
				System.out.println("Input your starting building [Garage|Apartment|Ofice]: ");
				building=scan.nextLine();
				
			}while(!building.equals("Garage") && !building.equals("Apartment") && !building.equals("Office"));
			String companyname=null;
//			newcompany = new Company(cash,building);
			
		//	companies.add(newcompany);
			System.out.println("Company Information");
			System.out.println("Cash: "+cash);
			System.out.println("Building: "+building);
			System.out.println("[Employee]");
			System.out.println("=====================================================================================================");	
			System.out.println("|No|                             	Employee Name |    Level |     Wage | Specialization |   Status |");
			for(int i=0;i<starting;i++) {
				if(!(companies instanceof Company)) {
					
					Company temp= (Company) companies.get(i);
					Employee temp1= (Emloyee) temp;
					System.out.printf("|%2d| %20s | %7d | %10d | %14s | %10s |\n",temp1.getEmployeename(),temp1.getLevel(),temp1.getWage(),temp1.getSpecialization(),temp1.getStatus());
				}
			}
			System.out.println("=====================================================================================================");
			
			do {
				System.out.print("Confirm your company [Y/N]: ");
				yesno=scan.nextLine();
			}while(!yesno.equalsIgnoreCase("Y") && !yesno.equalsIgnoreCase("N"));
			
			System.out.print("Please give your company a name: ");
			companyname=scan.nextLine();
			
			newcompany=new Company(companyname,cash,building);
			companies.add(newcompany);
			
			MainMenu(companyname,cash,building);
		}
		
		
		
	}
	
	
	public void ViewHighScore() {
		
		
	}
	
	public Main() {
		int choose;
		do {
			System.out.println("IT SOLUTION TYCOON");
			System.out.println("Menu\n1. Play Game\n2. View Highscore\n3. Exit Game\n>> ");
			choose=scan.nextInt();
			switch(choose) {
			case 1:{
				PlayGame();
				break;
				
			}
			case 2:{
				ViewHighScore();
				break;
				
			}
			
			}
			
		}while(choose!=3);
		
		
		
		
	}
	
	public static void main(String[] args) {
		new Main();
	}

}
