package ITSolutionTycoon;

import java.util.Scanner;

public class Utility {
	Scanner scan= new Scanner(System.in);
	
	public void entertocontinue() {
	System.out.println("Press enter to continue");
	scan.nextLine();
	}
	
	public void cls() {
		for(int i=0;i<100;i++) {
			System.out.println(" ");
		}
	}
}
