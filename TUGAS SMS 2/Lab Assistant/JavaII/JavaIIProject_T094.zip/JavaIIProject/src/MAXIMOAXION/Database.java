package MAXIMOAXION;

public class Database {

	public Database() {
		
	}

}
