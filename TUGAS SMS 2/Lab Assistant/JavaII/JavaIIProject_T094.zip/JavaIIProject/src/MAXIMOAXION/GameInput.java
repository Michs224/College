package MAXIMOAXION;

public class GameInput {

	public GameInput() {
		
	}

}
