package MAXIMOAXION;

public class GameMaster {

	public GameMaster() {
		
	}

}
