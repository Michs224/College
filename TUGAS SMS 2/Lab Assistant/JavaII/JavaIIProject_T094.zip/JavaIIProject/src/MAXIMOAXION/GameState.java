package MAXIMOAXION;

public class GameState {

	public GameState() {
		
	}

}
