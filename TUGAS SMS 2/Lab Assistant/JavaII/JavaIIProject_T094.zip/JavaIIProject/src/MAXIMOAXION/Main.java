package MAXIMOAXION;

import java.io.File;
import java.io.FileNotFoundException;
import java.io.FileWriter;
import java.io.IOException;
import java.util.ArrayList;
import java.util.List;
import java.util.Scanner;

public class Main {
	Scanner scan= new Scanner(System.in);
	Utility utility=new Utility();
	
	List<Player> players = new ArrayList<Player>();
	
	public void GamePage(Player player) {
		
	}
	
	public void HighScore() {
		
		
	}
	
//	public boolean validRegist(String username,String password) {
//		File currentFile=new File("save.txt");
//		Scanner fileReader=null;
//		try {
//			fileReader= new Scanner(currentFile);
//		} catch (FileNotFoundException e) {
//			// TODO Auto-generated catch block
//			e.printStackTrace();
//		}
//		//List<Player> listPlayer = new ArrayList<Player>();
//		
//		while(fileReader.hasNextLine()) {
//			String readed= fileReader.nextLine();
//			String [] data=readed.split("#");
//			Player player=new Player(null, null, null, null, null, null, null, null, null, null, null);
//			player.username=data[0];
//			player.password=data[1];
//			player.score=Integer.parseInt(data[2]);
//			if(username.equals(player.username) && password.equals(player.password)) {
//				return false;
//			}
//		}
//		return true;
//	}
	
	
	public void Register() {
		
		String username,password;
		Integer score=0;
		int check=0;
		do {
		do {
			
			System.out.print("Enter username [5..20]: ");
			username=scan.nextLine();
		}while(username.length()<5 || username.length()>20);
		do {
			
			System.out.print("Enter password [5..20]: ");
			password=scan.nextLine();
		}while(password.length()<5 || password.length()>20);
		
		File currentFile=new File("save.txt");
		try {
			currentFile.createNewFile();
		} catch (IOException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Scanner fileReader=null;
		try {
			fileReader= new Scanner(currentFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		//List<Player> listPlayer = new ArrayList<Player>();
		while(fileReader.hasNextLine()) {
			String readed= fileReader.nextLine();
			String [] data=readed.split("#");
			if(username.equals(data[0]) && password.equals(data[1])) {
				check=1;
				break;
			}
			
		}
		fileReader.close();
		
		if(check==1) {
			System.out.println("\nPlayer already registered!\n");
		}
		else {
			Player newplayer= new Player(username, password, score, null, null, null, null, null, null, null, null);
		
//			player.username=username;
//			player.password=password;
//			player.score=score;
			players.add(newplayer);
			try {
				FileWriter writer= new FileWriter(currentFile);
				
				for (Player player2 : players) {
					writer.write(player2.username+"#"+player2.password+"#"+player2.score+"\n");
					
				}
				writer.close();
			} catch (IOException e) {
				e.printStackTrace();
			}catch(NullPointerException e) {
				e.printStackTrace();
			}
			
			System.out.println("\nRegister Successfully!");
		}
		utility.PressEnterToContinue();
		utility.Cls();			
		}while(check==1);
		
	}
	
	public void Play() {
		String username,password;
		int check=0;
		do {
			
		do {
			
			System.out.print("Enter username [5..20]: ");
			username=scan.nextLine();
		}while(username.length()<5 || username.length()>20);
		do {
			
			System.out.print("Enter password [5..20]: ");
			password=scan.nextLine();
		}while(password.length()<5 || password.length()>20);
		
		File currentFile=new File("save.txt");
		Scanner fileReader=null;
		try {
			fileReader= new Scanner(currentFile);
		} catch (FileNotFoundException e) {
			// TODO Auto-generated catch block
			e.printStackTrace();
		}
		Player player=new Player(null, null, null, null, null, null, null, null, null, null, null);
		while(fileReader.hasNextLine()) {
			String readed= fileReader.nextLine();
			String [] data=readed.split("#");

			if(username.equals(data[0]) && password.equals(data[1])) {
				player.username=data[0];
				player.password=data[1];
				player.score=Integer.parseInt(data[2]);
				check=1;
				break;
			}
		}
		fileReader.close();
		if(check==1) {
			GamePage(player);
			utility.Cls();
		}
		else {
			System.out.println("\nPlayer not found!\n");
			utility.PressEnterToContinue();
			utility.Cls();
		}			
		}while(check==0);
		
		
	}
	
	
	public Main() {
		System.out.println("MAXIMOAXION");
		utility.PressEnterToContinue();
		utility.Cls();
		int choice;
		do {
			System.out.print("1. Play\n2. Register\n3. HighScore\n4. Exit\n>> ");
			choice=scan.nextInt();
			scan.nextLine();
			switch(choice) {
			case 1:{
				Play();
				break;
			}
			case 2:{
				Register();
				break;
			}
			case 3:{
				HighScore();
				break;
			}
			}
			
		}while(choice!=4);
		
		System.out.println("\nTHANK YOU!\n");
		
	}

	public static void main(String[] args) {
		new Main();
	}

}
