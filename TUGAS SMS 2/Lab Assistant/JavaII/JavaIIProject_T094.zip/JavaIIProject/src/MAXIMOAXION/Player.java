package MAXIMOAXION;

public class Player {
	String username,password;
	Integer score,wood,food,water,herb,health,hunger,thirst,shelter;
	public Player(String username, String password, Integer score, Integer wood, Integer food, Integer water,
			Integer herb, Integer health, Integer hunger, Integer thirst, Integer shelter) {
		super();
		this.username = username;
		this.password = password;
		this.score = score;
		this.wood = wood;
		this.food = food;
		this.water = water;
		this.herb = herb;
		this.health = health;
		this.hunger = hunger;
		this.thirst = thirst;
		this.shelter = shelter;
	}
	
	


	



}
