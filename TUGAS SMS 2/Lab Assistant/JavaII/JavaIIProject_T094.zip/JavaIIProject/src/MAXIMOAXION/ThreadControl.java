package MAXIMOAXION;

public class ThreadControl {

	public ThreadControl() {
		
	}

}
