package MAXIMOAXION;

import java.util.Scanner;

public class Utility {
	Scanner scan=new Scanner(System.in);
	public void PressEnterToContinue() {
		System.out.println("Press [Enter] to continue..");
		scan.nextLine();
	}
	public void Cls() {
		for(int i=0;i<100;i++) {
			System.out.println("");
		}
	}

}
